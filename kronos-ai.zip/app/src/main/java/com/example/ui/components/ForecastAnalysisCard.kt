package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.analytics.ForecastAnalysisData
import com.example.ui.theme.KronosBearish
import com.example.ui.theme.KronosBullish

@Composable
fun ForecastAnalysisCard(
    analysis: ForecastAnalysisData,
    currencySymbol: String = "",
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "DESCRIPTIVE FORECAST METRICS",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                MetricColumn(
                    "Forecast Return",
                    "${if (analysis.forecastChangePercent >= 0) "+" else ""}${String.format("%.2f", analysis.forecastChangePercent)}%",
                    Modifier.weight(1f),
                    if (analysis.forecastChangePercent >= 0) KronosBullish else KronosBearish
                )
                MetricColumn(
                    "Forecast Range",
                    "$currencySymbol${String.format("%.2f", analysis.forecastRange)}",
                    Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                MetricColumn(
                    "Avg Bar Range",
                    "$currencySymbol${String.format("%.2f", analysis.averagePredictedRange)}",
                    Modifier.weight(1f)
                )
                MetricColumn(
                    "Volatility Proxy",
                    "${String.format("%.2f", analysis.volatilityProxyPercent)}%",
                    Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                MetricColumn(
                    "Max Upside",
                    "+${String.format("%.2f", analysis.maxUpsidePercent)}%",
                    Modifier.weight(1f),
                    KronosBullish
                )
                MetricColumn(
                    "Max Downside",
                    "${String.format("%.2f", analysis.maxDownsidePercent)}%",
                    Modifier.weight(1f),
                    KronosBearish
                )
            }
        }
    }
}

@Composable
private fun MetricColumn(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    highlightColor: androidx.compose.ui.graphics.Color? = null
) {
    Column(modifier = modifier) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
            color = highlightColor ?: MaterialTheme.colorScheme.onSurface
        )
    }
}
