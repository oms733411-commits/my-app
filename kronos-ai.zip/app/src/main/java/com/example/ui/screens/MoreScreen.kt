package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.KronosModelId
import com.example.ui.KronosViewModel
import com.example.ui.theme.KronosAccentBlue
import com.example.ui.theme.KronosBullish
import com.example.ui.theme.KronosPrimary

@Composable
fun MoreScreen(
    viewModel: KronosViewModel,
    onNavigateToForecast: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val modelStatus by viewModel.modelManager.status.collectAsState()
    val isValidating by viewModel.isValidatingModel.collectAsState()
    val validationReport by viewModel.validationReport.collectAsState()
    val isBenchmarking by viewModel.isBenchmarking.collectAsState()
    val benchmarkResult by viewModel.benchmarkResult.collectAsState()

    var csvInputText by remember { mutableStateOf("") }
    val importedCsv by viewModel.importedCsv.collectAsState()
    val csvError by viewModel.csvError.collectAsState()

    var useMarketTz by remember { mutableStateOf(true) }
    var expertMode by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: Model Management
        item {
            Text(
                "KRONOS FOUNDATION MODEL",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                modelStatus.activeModel.displayName,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                "${modelStatus.activeModel.parameterCount} parameters • ${modelStatus.activeModel.maxContext} context length",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            color = KronosBullish.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                "READY",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = KronosBullish
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        modelStatus.activeModel.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(12.dp))

                    // Switch Model
                    Text("Select Active Model:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        KronosModelId.entries.forEach { m ->
                            FilterChip(
                                selected = modelStatus.activeModel == m,
                                onClick = { viewModel.modelManager.setActiveModel(m) },
                                label = { Text(m.displayName) },
                                modifier = Modifier.height(32.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    // Benchmark Test Button
                    OutlinedButton(
                        onClick = { viewModel.runBenchmark() },
                        enabled = !isBenchmarking,
                        modifier = Modifier.fillMaxWidth().testTag("run_benchmark_button")
                    ) {
                        if (isBenchmarking) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Benchmarking device...")
                        } else {
                            Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Run Model Benchmark Test")
                        }
                    }

                    benchmarkResult?.let { res ->
                        Spacer(Modifier.height(10.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Benchmark Results (${res.model.displayName}):", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                Text("• Inference Latency: ${res.inferenceTimeMs} ms", style = MaterialTheme.typography.bodySmall)
                                Text("• Throughput: ${String.format("%.1f", res.throughputCandlesPerSec)} candles / sec", style = MaterialTheme.typography.bodySmall)
                                Text("• RAM footprint estimate: ${res.memoryEstimateMb} MB", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }

        // Section: Official Model Validation Pipeline (Section 7)
        item {
            Text(
                "OFFICIAL VALIDATION PIPELINE",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Verify Python Reference Equivalence",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        "Feeds reference financial benchmark candles to verify mobile tokenizer and autoregressive generator against the official Kronos baseline.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.runModelValidation() },
                        enabled = !isValidating,
                        modifier = Modifier.fillMaxWidth().testTag("run_validation_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = KronosAccentBlue)
                    ) {
                        if (isValidating) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Running validation pipeline...")
                        } else {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Execute Equivalence Validation")
                        }
                    }

                    validationReport?.let { report ->
                        Spacer(Modifier.height(12.dp))
                        Surface(
                            color = if (report.isMathematicallyEquivalent) KronosBullish.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, if (report.isMathematicallyEquivalent) KronosBullish else MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = KronosBullish,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        "Validation Status: PASSED",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = KronosBullish
                                    )
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "• Tokenizer BSQ Reconstruction MAE: ${String.format("%.4f", report.tokenizerReconstructionMae)}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    "• Tokenizer Match: ${String.format("%.1f", report.tokenizerMatchPercentage)}%",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    "• Directional Cosine Similarity: ${String.format("%.4f", report.cosineSimilarity)}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    "• Decoded Forecast Price MAE: ${String.format("%.3f", report.forecastPriceMae)}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    report.summary,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: CSV Data Import & Management (Sections 15-18)
        item {
            Text(
                "CSV DATA IMPORT & VALIDATION",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Import Custom Financial Data",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        "Accepts CSV with timestamp/date, open, high, low, close, and volume.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(10.dp))

                    OutlinedTextField(
                        value = csvInputText,
                        onValueChange = { csvInputText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 100.dp, max = 160.dp)
                            .testTag("csv_input_field"),
                        placeholder = {
                            Text(
                                "Paste CSV text here...\nExample:\ndate,open,high,low,close,volume\n2024-01-01,150.0,152.0,149.0,151.5,100000\n2024-01-02,151.5,153.0,150.2,152.8,120000..."
                            )
                        },
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Sample CSV Loader
                        OutlinedButton(
                            onClick = {
                                val sample = buildString {
                                    append("timestamp,open,high,low,close,volume\n")
                                    var p = 2500.0
                                    val t0 = 1704067200000L
                                    for (i in 0..40) {
                                        val o = p
                                        val c = p + (kotlin.math.sin(i * 0.4) * 15.0)
                                        val h = maxOf(o, c) + 5.0
                                        val l = minOf(o, c) - 5.0
                                        append("${t0 + i * 86400000L},${String.format("%.2f", o)},${String.format("%.2f", h)},${String.format("%.2f", l)},${String.format("%.2f", c)},250000\n")
                                        p = c
                                    }
                                }
                                csvInputText = sample
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Load Sample CSV", style = MaterialTheme.typography.labelSmall)
                        }

                        // Parse & Validate Button
                        Button(
                            onClick = {
                                if (csvInputText.isNotBlank()) {
                                    viewModel.importCsv(csvInputText)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = KronosPrimary)
                        ) {
                            Text("Parse & Validate", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    csvError?.let { err ->
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Import Error: $err",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    // Validation & Preview Results
                    importedCsv?.let { parsed ->
                        Spacer(Modifier.height(12.dp))
                        val v = parsed.validationResult
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    "Validation: ${if (v.isValid) "VALID DATASET" else "HAS ISSUES"}",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (v.isValid) KronosBullish else MaterialTheme.colorScheme.error
                                )
                                Text("• Rows: ${v.rowCount}", style = MaterialTheme.typography.bodySmall)
                                Text("• Date Range: ${v.startDateFormatted} to ${v.endDateFormatted}", style = MaterialTheme.typography.bodySmall)
                                Text("• Has Volume: ${if (v.hasVolume) "Yes" else "No (Zero/Missing)"}", style = MaterialTheme.typography.bodySmall)

                                if (v.warnings.isNotEmpty()) {
                                    v.warnings.forEach { w ->
                                        Text("⚠ $w", style = MaterialTheme.typography.labelSmall, color = Color(0xFFD97706))
                                    }
                                }
                                if (v.errors.isNotEmpty()) {
                                    v.errors.forEach { e ->
                                        Text("✖ $e", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                    }
                                }

                                Spacer(Modifier.height(8.dp))
                                Button(
                                    onClick = onNavigateToForecast,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = KronosBullish)
                                ) {
                                    Text("Open in Forecast Workspace", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section: Settings & Environment
        item {
            Text(
                "PREFERENCES & SETTINGS",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Market Timezone Display", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                            Text("Show exchange time (IST for NSE, EST for NYSE)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = useMarketTz, onCheckedChange = { useMarketTz = it })
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Quantitative Expert Mode", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                            Text("Show raw distributions, volatility proxies, and tokens", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = expertMode, onCheckedChange = { expertMode = it })
                    }
                }
            }
        }

        // Section: Attribution & Open Source
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "ABOUT KRONOS AI",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Kronos is an open-source financial time-series foundation model architecture created by shiyu-coder/Kronos. " +
                                "Pre-trained on 12 billion K-line records across 45 global exchanges, it applies Binary Spherical Quantization (BSQ) " +
                                "and causal autoregressive transformers to model market dynamics.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(8.dp))
                    Text("• HuggingFace: NeoQuasar/Kronos-base", style = MaterialTheme.typography.bodySmall)
                    Text("• License: Open Source (Research & Education)", style = MaterialTheme.typography.bodySmall)
                    Text("• Free-First Guarantee: ₹0 mandatory cost, runs completely local", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
