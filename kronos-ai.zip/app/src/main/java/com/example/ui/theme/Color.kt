package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Tones
val KronosNavyDark = Color(0xFF080D1A)
val KronosSurfaceDark = Color(0xFF10192C)
val KronosCardDark = Color(0xFF152238)
val KronosBorderDark = Color(0xFF1E2F4C)

val KronosBackgroundLight = Color(0xFFF8FAFC)
val KronosSurfaceLight = Color(0xFFFFFFFF)
val KronosCardLight = Color(0xFFFFFFFF)
val KronosBorderLight = Color(0xFFE2E8F0)

val KronosPrimary = Color(0xFF1E293B)
val KronosPrimaryLight = Color(0xFF0F172A)
val KronosAccentBlue = Color(0xFF2563EB)
val KronosAccentGold = Color(0xFFD97706)
val KronosAccentCyan = Color(0xFF0284C7)

// Financial Semantic Colors
val KronosBullish = Color(0xFF10B981) // Subtle Green
val KronosBullishBg = Color(0xFFECFDF5)
val KronosBearish = Color(0xFFEF4444) // Subtle Red
val KronosBearishBg = Color(0xFFFEF2F2)
val KronosNeutral = Color(0xFF64748B)

// Forecast Highlighting
val KronosForecastColor = Color(0xFFF59E0B) // Amber for predicted
val KronosForecastBg = Color(0xFFFFFBEB)
val KronosActualColor = Color(0xFF3B82F6) // Blue/Slate for actual

