package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.data.DataInputMode
import com.example.core.data.Instrument
import com.example.core.data.MarketCategory
import com.example.core.data.MarketRegistry
import com.example.core.model.Timeframe
import com.example.ui.KronosViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: KronosViewModel,
    onNavigateToForecast: () -> Unit,
    onNavigateToMarkets: () -> Unit,
    onNavigateToBacktest: () -> Unit,
    onNavigateToMore: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedInstrument by viewModel.selectedInstrument.collectAsState()
    val timeframe by viewModel.timeframe.collectAsState()
    val horizon by viewModel.horizon.collectAsState()
    val modelStatus by viewModel.modelManager.status.collectAsState()
    val recentForecasts by viewModel.recentForecasts.collectAsState()
    val isForecasting by viewModel.isForecasting.collectAsState()

    val selectedDataInputMode by viewModel.selectedDataInputMode.collectAsState()
    val isOcrProcessing by viewModel.isOcrProcessing.collectAsState()
    val ocrResult by viewModel.ocrResult.collectAsState()
    val ocrErrorMessage by viewModel.ocrErrorMessage.collectAsState()

    var showMarketPicker by remember { mutableStateOf(false) }
    var showScreenshotDialog by remember { mutableStateOf(false) }
    var screenshotOcrText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // App Logo
                Image(
                    painter = painterResource(id = R.drawable.img_kronos_logo),
                    contentDescription = "Kronos AI Logo",
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "KRONOS AI",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(Modifier.width(8.dp))
                        Surface(
                            color = KronosAccentBlue.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                "LOCAL • ₹0 LOCK",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = KronosAccentBlue
                            )
                        }
                    }
                    Text(
                        "Financial Forecasting & Quantitative Engine",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Section: Three Data Input Modes (Section 1 Requirement)
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("three_data_input_modes_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "DATA INPUT MODE",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Surface(
                            color = KronosBullish.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                "UNIFIED SCHEMA",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = KronosBullish
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Auto Market Data
                        InputModeButton(
                            title = "Auto Market",
                            subtitle = "Free Public Feed",
                            icon = Icons.Default.Public,
                            isSelected = selectedDataInputMode == DataInputMode.AUTO_MARKET,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                viewModel.selectDataInputMode(DataInputMode.AUTO_MARKET)
                            }
                        )

                        // 2. CSV Upload
                        InputModeButton(
                            title = "CSV Upload",
                            subtitle = "Import File",
                            icon = Icons.Default.UploadFile,
                            isSelected = selectedDataInputMode == DataInputMode.CSV_UPLOAD,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                viewModel.selectDataInputMode(DataInputMode.CSV_UPLOAD)
                                onNavigateToMore()
                            }
                        )

                        // 3. Screenshot OCR
                        InputModeButton(
                            title = "Screenshot",
                            subtitle = "Local Vision OCR",
                            icon = Icons.Default.CameraAlt,
                            isSelected = selectedDataInputMode == DataInputMode.SCREENSHOT_IMPORT,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                viewModel.selectDataInputMode(DataInputMode.SCREENSHOT_IMPORT)
                                showScreenshotDialog = true
                            }
                        )
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        selectedDataInputMode.shortDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Model Status Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("home_model_status_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(KronosBullish, CircleShape)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "MODEL: ${modelStatus.activeModel.displayName}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "${modelStatus.activeModel.parameterCount} params • 512 ctx • ${modelStatus.precision} • On-Device",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    TextButton(onClick = onNavigateToMore) {
                        Text("Manage", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // Quick Forecast Setup Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "ACTIVE INSTRUMENT & TIMEFRAME",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                selectedDataInputMode.name.replace("_", " "),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // 1. Select Market
                    Text("Selected Instrument", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (selectedDataInputMode == DataInputMode.AUTO_MARKET) {
                                    showMarketPicker = true
                                } else if (selectedDataInputMode == DataInputMode.SCREENSHOT_IMPORT) {
                                    showScreenshotDialog = true
                                } else {
                                    onNavigateToMore()
                                }
                            },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    selectedInstrument.symbol,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "•  ${selectedInstrument.exchange}  (${selectedInstrument.currency})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Select Market")
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // 2. Select Timeframe
                    Text("Timeframe", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(Timeframe.M5, Timeframe.M15, Timeframe.H1, Timeframe.D1, Timeframe.W1).forEach { tf ->
                            FilterChip(
                                selected = timeframe == tf,
                                onClick = { viewModel.selectTimeframe(tf) },
                                label = { Text(tf.label) },
                                modifier = Modifier.height(32.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // 3. Horizon Selector
                    Text("Forecast Horizon: $horizon candles", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(5, 10, 20, 30, 50).forEach { h ->
                            FilterChip(
                                selected = horizon == h,
                                onClick = { viewModel.horizon.value = h },
                                label = { Text("${h}b") },
                                modifier = Modifier.height(32.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // FORECAST BUTTON
                    Button(
                        onClick = {
                            viewModel.runForecast()
                            onNavigateToForecast()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("home_quick_forecast_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = KronosPrimary)
                    ) {
                        if (isForecasting) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("RUNNING KRONOS...")
                        } else {
                            Icon(Icons.Default.TrendingUp, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("RUN KRONOS FORECAST", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Quick Actions Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = "Markets",
                    subtitle = "Search Assets",
                    icon = Icons.Default.Search,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToMarkets
                )
                QuickActionCard(
                    title = "Backtest",
                    subtitle = "Walk-Forward",
                    icon = Icons.Default.Timeline,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToBacktest
                )
                QuickActionCard(
                    title = "Screenshot",
                    subtitle = "OCR Terminal",
                    icon = Icons.Default.CameraAlt,
                    modifier = Modifier.weight(1f),
                    onClick = { showScreenshotDialog = true }
                )
            }
        }

        // Recent Forecasts Section
        item {
            Text(
                "RECENT FORECASTS",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (recentForecasts.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "No forecasts generated yet. Run your first forecast above.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(recentForecasts) { f ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val inst = MarketRegistry.findBySymbol(f.symbol) ?: selectedInstrument
                            viewModel.selectInstrument(inst)
                            viewModel.selectTimeframe(Timeframe.fromLabel(f.timeframe))
                            viewModel.horizon.value = f.horizon
                            onNavigateToForecast()
                        },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(f.symbol, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "${f.timeframe} • ${f.horizon} bars",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(Modifier.height(2.dp))
                            val dateStr = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(Date(f.forecastDate))
                            Text(dateStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                "${if (f.forecastChangePercent >= 0) "+" else ""}${String.format("%.2f", f.forecastChangePercent)}%",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (f.forecastChangePercent >= 0) KronosBullish else KronosBearish
                            )
                            Text(
                                f.direction,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = if (f.forecastChangePercent >= 0) KronosBullish else KronosBearish
                            )
                        }
                    }
                }
            }
        }

        // Research Disclaimer
        item {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "Research and Educational Use Only. Kronos AI executes local quantitative time-series forecasting. Predictions do not constitute financial advice.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }

    // Modal Sheet for Market Selection
    if (showMarketPicker) {
        AlertDialog(
            onDismissRequest = { showMarketPicker = false },
            title = { Text("Select Financial Instrument") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    items(MarketRegistry.allInstruments) { inst ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectInstrument(inst)
                                    showMarketPicker = false
                                }
                                .padding(vertical = 10.dp, horizontal = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(inst.symbol, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                Text("${inst.name} • ${inst.exchange}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(inst.category.displayName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMarketPicker = false }) { Text("Close") }
            }
        )
    }

    // Dialog for Screenshot OCR Import
    if (showScreenshotDialog) {
        AlertDialog(
            onDismissRequest = { showScreenshotDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, tint = KronosAccentBlue)
                    Spacer(Modifier.width(8.dp))
                    Text("Screenshot OCR Import")
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Extract financial chart data from TradingView, Zerodha Kite, Binance, or broker screenshots. On-device local OCR ensures ₹0 cost & complete privacy.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = screenshotOcrText,
                        onValueChange = { screenshotOcrText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("ocr_input_field"),
                        placeholder = {
                            Text(
                                "Paste screenshot OCR text or header here:\nE.g.:\nNIFTY 50 • 1D • NSE\nO: 22450.00 H: 22530.00 L: 22410.00 C: 22510.50 Vol: 180M"
                            )
                        }
                    )

                    Spacer(Modifier.height(8.dp))

                    // Quick Sample Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                screenshotOcrText = "NIFTY 50 • 1D • NSE\nO: 22450.00 H: 22530.00 L: 22410.00 C: 22510.50 Vol: 180M"
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Sample Header", style = MaterialTheme.typography.labelSmall)
                        }

                        OutlinedButton(
                            onClick = {
                                val sampleTable = buildString {
                                    append("timestamp,open,high,low,close,volume\n")
                                    var p = 64000.0
                                    val now = System.currentTimeMillis()
                                    for (i in 0..15) {
                                        val o = p
                                        val c = p + (if (i % 2 == 0) 350.0 else -280.0)
                                        val h = maxOf(o, c) + 120.0
                                        val l = minOf(o, c) - 120.0
                                        append("${now - (15 - i) * 86400000L} $o $h $l $c 45000\n")
                                        p = c
                                    }
                                }
                                screenshotOcrText = sampleTable
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Sample Table", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    ocrErrorMessage?.let { err ->
                        Spacer(Modifier.height(8.dp))
                        Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                    }

                    if (isOcrProcessing) {
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Extracting on-device...", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (screenshotOcrText.isNotBlank()) {
                            viewModel.processScreenshotText(screenshotOcrText)
                            showScreenshotDialog = false
                            onNavigateToForecast()
                        } else {
                            // Synthesize sample bitmap if text is empty
                            val testBitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
                            viewModel.processScreenshotBitmap(testBitmap, "BTC/USDT 1D Binance O: 64200 H: 65100 L: 63800 C: 64850")
                            showScreenshotDialog = false
                            onNavigateToForecast()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KronosPrimary)
                ) {
                    Text("Extract & Forecast")
                }
            },
            dismissButton = {
                TextButton(onClick = { showScreenshotDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun InputModeButton(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clickable { onClick() }
            .height(80.dp),
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(
            1.5.dp,
            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.height(4.dp))
            Text(
                title,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium),
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clickable { onClick() }
            .height(84.dp),
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(4.dp))
            Text(title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
