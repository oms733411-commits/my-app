package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.analytics.BacktestReport
import com.example.ui.KronosViewModel
import com.example.ui.theme.KronosBearish
import com.example.ui.theme.KronosBullish
import com.example.ui.theme.KronosPrimary
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun BacktestScreen(
    viewModel: KronosViewModel,
    modifier: Modifier = Modifier
) {
    val instrument by viewModel.selectedInstrument.collectAsState()
    val timeframe by viewModel.timeframe.collectAsState()
    val isBacktesting by viewModel.isBacktesting.collectAsState()
    val backtestProgress by viewModel.backtestProgress.collectAsState()
    val backtestReport by viewModel.backtestReport.collectAsState()

    var lookback by remember { mutableStateOf(60) }
    var horizon by remember { mutableStateOf(10) }
    var numWindows by remember { mutableStateOf(5) }
    var stride by remember { mutableStateOf(10) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    "WALK-FORWARD BACKTEST ENGINE",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    "Evaluate Kronos forecast accuracy against real historical out-of-sample data with zero data leakage.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Setup Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "BACKTEST CONFIGURATION",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))

                    Text(
                        "Instrument: ${instrument.symbol} (${instrument.exchange}) • Timeframe: ${timeframe.label}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )

                    Spacer(Modifier.height(12.dp))

                    // Parameters
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Lookback Context", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$lookback bars", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                        }
                        Column {
                            Text("Forecast Horizon", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$horizon bars", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                        }
                        Column {
                            Text("Rolling Windows", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$numWindows windows", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Run Button
                    Button(
                        onClick = { viewModel.runBacktest(lookback, horizon, numWindows, stride) },
                        enabled = !isBacktesting,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("run_backtest_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = KronosPrimary)
                    ) {
                        if (isBacktesting) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            val p = backtestProgress
                            Text("EVALUATING WINDOW ${p?.first ?: 1} OF ${p?.second ?: numWindows}...")
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("RUN WALK-FORWARD BACKTEST", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Comparative Results
        backtestReport?.let { report ->
            item {
                Text(
                    "MODEL VS NAIVE PERSISTENCE BASELINE",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Metric", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                            Text("Kronos AI", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                            Text("Naive Baseline", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant))
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        MetricCompareRow("MAE (Error)", String.format("%.2f", report.kronosMetrics.mae), String.format("%.2f", report.naiveMetrics.mae))
                        MetricCompareRow("RMSE", String.format("%.2f", report.kronosMetrics.rmse), String.format("%.2f", report.naiveMetrics.rmse))
                        MetricCompareRow("MAPE", "${String.format("%.2f", report.kronosMetrics.mape)}%", "${String.format("%.2f", report.naiveMetrics.mape)}%")
                        MetricCompareRow("Directional Acc.", "${String.format("%.1f", report.kronosMetrics.directionalAccuracyPercent)}%", "${String.format("%.1f", report.naiveMetrics.directionalAccuracyPercent)}%")
                    }
                }
            }

            // Window-by-Window Details
            item {
                Text(
                    "WINDOW-BY-WINDOW BREAKDOWN (${report.numWindows} windows)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            items(report.windowResults) { win ->
                val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date(win.splitTimestamp))
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Window #${win.windowIndex} • $dateStr", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text(
                                "Kronos MAE: ${String.format("%.2f", win.kronosMae)}  (Baseline: ${String.format("%.2f", win.naiveMae)})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (win.directionalMatch) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Direction matched", tint = KronosBullish, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Direction Hit", style = MaterialTheme.typography.labelSmall, color = KronosBullish, fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.Cancel, contentDescription = "Direction missed", tint = KronosBearish, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Direction Miss", style = MaterialTheme.typography.labelSmall, color = KronosBearish)
                            }
                        }
                    }
                }
            }
        } ?: run {
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "Click 'RUN WALK-FORWARD BACKTEST' to evaluate Kronos out-of-sample performance across rolling time windows.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }

        // Backtest Zero-Leakage Guarantee Note
        item {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "Zero Data Leakage Guarantee: At each rolling window, the model context is strictly restricted to past bars prior to the split point. Future candles are withheld until evaluation.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }
}

@Composable
private fun MetricCompareRow(label: String, kronosVal: String, naiveVal: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(kronosVal, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
        Text(naiveVal, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
