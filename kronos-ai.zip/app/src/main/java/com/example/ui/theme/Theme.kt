package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = KronosAccentBlue,
    onPrimary = Color.White,
    primaryContainer = KronosBorderDark,
    onPrimaryContainer = Color.White,
    secondary = KronosAccentGold,
    onSecondary = Color.Black,
    tertiary = KronosAccentCyan,
    background = KronosNavyDark,
    onBackground = Color(0xFFF1F5F9),
    surface = KronosSurfaceDark,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = KronosCardDark,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = KronosBorderDark
)

private val LightColorScheme = lightColorScheme(
    primary = KronosPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF1F5F9),
    onPrimaryContainer = KronosPrimaryLight,
    secondary = KronosAccentBlue,
    onSecondary = Color.White,
    tertiary = KronosAccentGold,
    background = KronosBackgroundLight,
    onBackground = Color(0xFF0F172A),
    surface = KronosSurfaceLight,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF8FAFC),
    onSurfaceVariant = Color(0xFF64748B),
    outline = KronosBorderLight
)

@Composable
fun KronosTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

