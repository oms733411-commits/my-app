package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.analytics.TechnicalIndicators
import com.example.core.model.KronosModelId
import com.example.core.model.Timeframe
import com.example.ui.KronosViewModel
import com.example.ui.components.*
import com.example.ui.theme.KronosAccentBlue
import com.example.ui.theme.KronosBullish
import com.example.ui.theme.KronosForecastColor
import com.example.ui.theme.KronosPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForecastScreen(
    viewModel: KronosViewModel,
    modifier: Modifier = Modifier
) {
    val instrument by viewModel.selectedInstrument.collectAsState()
    val timeframe by viewModel.timeframe.collectAsState()
    val historicalCandles by viewModel.historicalCandles.collectAsState()
    val forecastResult by viewModel.forecastResult.collectAsState()
    val forecastAnalysis by viewModel.forecastAnalysis.collectAsState()
    val isForecasting by viewModel.isForecasting.collectAsState()
    val forecastProgress by viewModel.forecastProgress.collectAsState()
    val modelStatus by viewModel.modelManager.status.collectAsState()

    val horizon by viewModel.horizon.collectAsState()
    val lookback by viewModel.lookback.collectAsState()
    val temperature by viewModel.temperature.collectAsState()
    val topP by viewModel.topP.collectAsState()
    val sampleCount by viewModel.sampleCount.collectAsState()

    val chartType by viewModel.chartType.collectAsState()
    val showVolume by viewModel.showVolume.collectAsState()
    val showSMA by viewModel.showSMA.collectAsState()
    val showEMA by viewModel.showEMA.collectAsState()
    val showBB by viewModel.showBollinger.collectAsState()
    val showRSI by viewModel.showRSI.collectAsState()
    val showMACD by viewModel.showMACD.collectAsState()
    val isLogScale by viewModel.isLogScale.collectAsState()

    val inputMode by viewModel.selectedDataInputMode.collectAsState()
    val isLiveStreaming by viewModel.isRealTimeStreaming.collectAsState()

    var showAdvancedOptions by remember { mutableStateOf(false) }

    // Compute technical indicators on historical dataset
    val smaPoints = remember(historicalCandles, showSMA) {
        if (showSMA) TechnicalIndicators.calculateSMA(historicalCandles, 20) else emptyList()
    }
    val emaPoints = remember(historicalCandles, showEMA) {
        if (showEMA) TechnicalIndicators.calculateEMA(historicalCandles, 20) else emptyList()
    }
    val bbPoints = remember(historicalCandles, showBB) {
        if (showBB) TechnicalIndicators.calculateBollingerBands(historicalCandles, 20) else emptyList()
    }
    val rsiPoints = remember(historicalCandles, showRSI) {
        if (showRSI) TechnicalIndicators.calculateRSI(historicalCandles, 14) else emptyList()
    }
    val macdPoints = remember(historicalCandles, showMACD) {
        if (showMACD) TechnicalIndicators.calculateMACD(historicalCandles) else emptyList()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Instrument Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            instrument.symbol,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(Modifier.width(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                instrument.exchange,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }
                    }
                    Text(
                        "${instrument.name} • Currency: ${instrument.currency} • Zone: ${instrument.timezone}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Model and Mode Tags
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            inputMode.name.replace("_", " "),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Surface(
                        color = KronosAccentBlue.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, KronosAccentBlue.copy(alpha = 0.3f))
                    ) {
                        Text(
                            modelStatus.activeModel.displayName,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = KronosAccentBlue
                        )
                    }
                }
            }
        }

        // Timeframe Selector Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    Timeframe.M1, Timeframe.M5, Timeframe.M15, Timeframe.M30,
                    Timeframe.H1, Timeframe.H4, Timeframe.D1, Timeframe.W1
                ).forEach { tf ->
                    FilterChip(
                        selected = timeframe == tf,
                        onClick = { viewModel.selectTimeframe(tf) },
                        label = { Text(tf.label) },
                        modifier = Modifier.height(32.dp)
                    )
                }
            }
        }

        // Forecast Parameters Bar (Horizon, Lookback, Run Button)
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Horizon Selector
                    Text("Forecast Horizon", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(1, 3, 5, 10, 20, 30, 50, 100).forEach { h ->
                            FilterChip(
                                selected = horizon == h,
                                onClick = { viewModel.horizon.value = h },
                                label = { Text("${h}b") },
                                modifier = Modifier.height(30.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Historical Lookback Selector
                    Text("Context Window: $lookback candles (up to 512 max)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(60, 120, 250, 512).forEach { lb ->
                            FilterChip(
                                selected = lookback == lb,
                                onClick = { viewModel.lookback.value = lb },
                                label = { Text("$lb") },
                                modifier = Modifier.height(30.dp)
                            )
                        }
                    }

                    // Advanced Options Toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { showAdvancedOptions = !showAdvancedOptions },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Icon(
                                if (showAdvancedOptions) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(if (showAdvancedOptions) "Hide Advanced Settings" else "Show Advanced Settings (Temp, Top-p, Ensemble)")
                        }
                    }

                    AnimatedVisibility(visible = showAdvancedOptions) {
                        Column(modifier = Modifier.padding(top = 8.dp)) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            Spacer(Modifier.height(8.dp))

                            // Model Selection
                            Text("Active Model Architecture:", style = MaterialTheme.typography.labelSmall)
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                KronosModelId.entries.forEach { m ->
                                    FilterChip(
                                        selected = modelStatus.activeModel == m,
                                        onClick = { viewModel.modelManager.setActiveModel(m) },
                                        label = { Text(m.displayName) },
                                        modifier = Modifier.height(30.dp)
                                    )
                                }
                            }

                            Spacer(Modifier.height(10.dp))

                            // Temperature Slider
                            Text(
                                "Sampling Temperature: ${String.format("%.1f", temperature)} (0.0 = Greedy deterministic)",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Slider(
                                value = temperature,
                                onValueChange = { viewModel.temperature.value = it },
                                valueRange = 0.0f..2.0f,
                                steps = 19
                            )

                            // Top-p Slider
                            Text(
                                "Nucleus Top-p: ${String.format("%.2f", topP)}",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Slider(
                                value = topP,
                                onValueChange = { viewModel.topP.value = it },
                                valueRange = 0.5f..1.0f,
                                steps = 9
                            )

                            // Ensemble Sample Count
                            Text(
                                "Sample Count (Ensemble Median & Spread): $sampleCount sample(s)",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(1, 3, 5).forEach { s ->
                                    FilterChip(
                                        selected = sampleCount == s,
                                        onClick = { viewModel.sampleCount.value = s },
                                        label = { Text("$s sample${if (s > 1) "s" else ""}") },
                                        modifier = Modifier.height(30.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // RUN KRONOS FORECAST BUTTON
                    Button(
                        onClick = { viewModel.runForecast() },
                        enabled = !isForecasting,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("run_forecast_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = KronosPrimary)
                    ) {
                        if (isForecasting) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("GENERATING FORECAST...")
                        } else {
                            Icon(Icons.Default.TrendingUp, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("RUN KRONOS FORECAST", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Truthful Pipeline Progress Indicator (Section 61)
        if (isForecasting && forecastProgress != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = KronosAccentBlue.copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, KronosAccentBlue.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Pipeline: ${forecastProgress?.message}...",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = KronosAccentBlue
                            )
                            Text(
                                "Step ${forecastProgress?.step} of ${forecastProgress?.totalSteps}",
                                style = MaterialTheme.typography.labelSmall,
                                color = KronosAccentBlue
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        val progressFraction = (forecastProgress?.step ?: 1).toFloat() / (forecastProgress?.totalSteps ?: 6)
                        LinearProgressIndicator(
                            progress = { progressFraction },
                            modifier = Modifier.fillMaxWidth(),
                            color = KronosAccentBlue
                        )
                    }
                }
            }
        }

        // Chart Toolbar: Chart Type & Technical Indicator Toggles
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Chart Type
                listOf(
                    Pair(ChartType.DUAL_COMPARISON, "⚡ Actual vs Kronos"),
                    Pair(ChartType.CANDLESTICK, "Candles"),
                    Pair(ChartType.LINE, "Line"),
                    Pair(ChartType.AREA, "Area")
                ).forEach { (ct, label) ->
                    FilterChip(
                        selected = chartType == ct,
                        onClick = { viewModel.chartType.value = ct },
                        label = { Text(label) },
                        modifier = Modifier.height(30.dp)
                    )
                }

                // Live Real-Time Stream Toggle Chip
                FilterChip(
                    selected = isLiveStreaming,
                    onClick = { viewModel.toggleRealTimeStreaming() },
                    label = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .background(
                                        if (isLiveStreaming) KronosBullish else Color.Gray,
                                        shape = androidx.compose.foundation.shape.CircleShape
                                    )
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(if (isLiveStreaming) "LIVE TICKING" else "STREAM OFF")
                        }
                    },
                    modifier = Modifier.height(30.dp)
                )

                // Separator
                Box(
                    modifier = Modifier
                        .height(20.dp)
                        .width(1.dp)
                        .background(MaterialTheme.colorScheme.outline)
                )

                // Indicators
                FilterChip(
                    selected = showSMA,
                    onClick = { viewModel.showSMA.value = !showSMA },
                    label = { Text("SMA 20") },
                    modifier = Modifier.height(30.dp)
                )
                FilterChip(
                    selected = showEMA,
                    onClick = { viewModel.showEMA.value = !showEMA },
                    label = { Text("EMA 20") },
                    modifier = Modifier.height(30.dp)
                )
                FilterChip(
                    selected = showBB,
                    onClick = { viewModel.showBollinger.value = !showBB },
                    label = { Text("BB 20,2") },
                    modifier = Modifier.height(30.dp)
                )
                FilterChip(
                    selected = showVolume,
                    onClick = { viewModel.showVolume.value = !showVolume },
                    label = { Text("Volume") },
                    modifier = Modifier.height(30.dp)
                )
                FilterChip(
                    selected = showRSI,
                    onClick = { viewModel.showRSI.value = !showRSI },
                    label = { Text("RSI 14") },
                    modifier = Modifier.height(30.dp)
                )
                FilterChip(
                    selected = showMACD,
                    onClick = { viewModel.showMACD.value = !showMACD },
                    label = { Text("MACD") },
                    modifier = Modifier.height(30.dp)
                )
            }
        }

        // Financial Candlestick Chart
        item {
            FinancialCandlestickChart(
                historicalCandles = historicalCandles,
                forecastCandles = forecastResult?.forecastCandles ?: emptyList(),
                smaPoints = smaPoints,
                emaPoints = emaPoints,
                bollingerBands = bbPoints,
                chartType = chartType,
                showVolume = showVolume,
                isLogScale = isLogScale
            )
        }

        // RSI Panel if enabled
        if (showRSI && rsiPoints.isNotEmpty()) {
            item {
                OscillatorPanel(
                    title = "RSI (14) - Relative Strength Index",
                    currentValue = rsiPoints.lastOrNull()?.value ?: 50.0,
                    oversold = 30.0,
                    overbought = 70.0
                )
            }
        }

        // MACD Panel if enabled
        if (showMACD && macdPoints.isNotEmpty()) {
            item {
                val lastMacd = macdPoints.last()
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("MACD (12, 26, 9)", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                        Text(
                            "MACD: ${String.format("%.2f", lastMacd.macd)}  Signal: ${String.format("%.2f", lastMacd.signal)}  Hist: ${String.format("%.2f", lastMacd.histogram)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        // Forecast Summary Card
        forecastAnalysis?.let { analysis ->
            item {
                ForecastSummaryCard(
                    analysis = analysis,
                    modelId = modelStatus.activeModel,
                    horizon = horizon,
                    currencySymbol = if (instrument.currency == "USD") "$" else if (instrument.currency == "INR") "₹" else ""
                )
            }

            item {
                ForecastAnalysisCard(
                    analysis = analysis,
                    currencySymbol = if (instrument.currency == "USD") "$" else if (instrument.currency == "INR") "₹" else ""
                )
            }
        }

        // Forecast Data Table (OHLCV)
        forecastResult?.let { result ->
            if (result.forecastCandles.isNotEmpty()) {
                item {
                    ForecastDataTable(
                        forecastCandles = result.forecastCandles,
                        symbol = instrument.symbol
                    )
                }
            }
        }

        // Disclaimers
        item {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "Kronos AI is designed strictly for research, benchmarking, and educational time-series study. " +
                            "Model outputs should never be construed as financial or trading advice.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }
}

@Composable
private fun OscillatorPanel(
    title: String,
    currentValue: Double,
    oversold: Double,
    overbought: Double
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(title, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                Text(
                    "Oversold < $oversold  •  Overbought > $overbought",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                String.format("%.2f", currentValue),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = if (currentValue > overbought) Color(0xFFEF4444) else if (currentValue < oversold) Color(0xFF10B981) else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
