package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.analytics.BollingerBandPoint
import com.example.core.analytics.IndicatorPoint
import com.example.core.model.Candle
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

enum class ChartType { CANDLESTICK, LINE, AREA, DUAL_COMPARISON }

@Composable
fun FinancialCandlestickChart(
    historicalCandles: List<Candle>,
    forecastCandles: List<Candle> = emptyList(),
    smaPoints: List<IndicatorPoint> = emptyList(),
    emaPoints: List<IndicatorPoint> = emptyList(),
    bollingerBands: List<BollingerBandPoint> = emptyList(),
    modifier: Modifier = Modifier,
    chartType: ChartType = ChartType.CANDLESTICK,
    showVolume: Boolean = true,
    isLogScale: Boolean = false,
    onCandleSelected: ((Candle?) -> Unit)? = null
) {
    val allCandles = remember(historicalCandles, forecastCandles) {
        historicalCandles + forecastCandles
    }

    if (allCandles.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(280.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "No chart data available",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    // Viewport control: visible window of candles
    var visibleCount by remember { mutableStateOf(min(60, allCandles.size)) }
    var scrollOffset by remember { mutableStateOf(max(0, allCandles.size - visibleCount)) }
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    // Keep scroll aligned to latest when dataset updates
    LaunchedEffect(allCandles.size) {
        visibleCount = min(60, allCandles.size)
        scrollOffset = max(0, allCandles.size - visibleCount)
    }

    // Pre-index indicators by timestamp into fast O(1) maps to prevent O(N^2) scans in draw loop
    val bbMap = remember(bollingerBands) { bollingerBands.associateBy { it.timestamp } }
    val smaMap = remember(smaPoints) { smaPoints.associateBy { it.timestamp } }
    val emaMap = remember(emaPoints) { emaPoints.associateBy { it.timestamp } }

    val visibleCandles = remember(allCandles, scrollOffset, visibleCount) {
        val safeCount = visibleCount.coerceIn(10, allCandles.size)
        val safeOffset = scrollOffset.coerceIn(0, max(0, allCandles.size - safeCount))
        allCandles.subList(safeOffset, min(allCandles.size, safeOffset + safeCount))
    }

    // Find min and max price for y-scale
    var minPrice = Double.MAX_VALUE
    var maxPrice = Double.MIN_VALUE
    var maxVolume = 1.0

    for (c in visibleCandles) {
        if (c.low < minPrice) minPrice = c.low
        if (c.high > maxPrice) maxPrice = c.high
        if (c.volume > maxVolume) maxVolume = c.volume
    }
    // Include Bollinger Bands in scale if present
    for (b in bollingerBands) {
        if (b.lower < minPrice) minPrice = b.lower
        if (b.upper > maxPrice) maxPrice = b.upper
    }
    if (minPrice >= maxPrice) {
        minPrice = maxPrice * 0.95
        maxPrice = maxPrice * 1.05
    }
    // 5% padding on y-axis
    val priceRange = maxPrice - minPrice
    val yMin = max(0.0001, minPrice - (priceRange * 0.05))
    val yMax = maxPrice + (priceRange * 0.05)

    val dateFormat = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.US) }

    Column(modifier = modifier.fillMaxWidth()) {
        // Dual Mode Legend if in comparison view
        if (chartType == ChartType.DUAL_COMPARISON) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Actual Price Legend
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp, 3.dp)
                                    .background(Color(0xFF38BDF8), RoundedCornerShape(2.dp))
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Actual / Live Price",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF38BDF8)
                            )
                        }

                        // Kronos Forecast Path Legend
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp, 3.dp)
                                    .background(KronosForecastColor, RoundedCornerShape(2.dp))
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Kronos AI Forecast Path",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = KronosForecastColor
                            )
                        }
                    }

                    // Spread Cloud tag
                    Text(
                        "± Ensemble Spread Ribbon",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Candle Inspector detail banner if candle tapped
        selectedIndex?.let { idx ->
            if (idx in visibleCandles.indices) {
                val candle = visibleCandles[idx]
                CandleInspectorBanner(candle, dateFormat) {
                    selectedIndex = null
                    onCandleSelected?.invoke(null)
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(310.dp)
                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                .pointerInput(allCandles.size) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        // Zoom
                        if (zoom != 1.0f) {
                            val newCount = (visibleCount / zoom).toInt().coerceIn(10, allCandles.size)
                            visibleCount = newCount
                            scrollOffset = scrollOffset.coerceIn(0, max(0, allCandles.size - visibleCount))
                        }
                        // Pan
                        if (pan.x != 0f) {
                            val candleWidthApprox = size.width / visibleCount
                            val deltaCandles = -(pan.x / candleWidthApprox).toInt()
                            scrollOffset = (scrollOffset + deltaCandles).coerceIn(0, max(0, allCandles.size - visibleCount))
                        }
                    }
                }
                .pointerInput(visibleCandles) {
                    detectTapGestures { offset ->
                        val n = visibleCandles.size
                        val candleWidth = size.width / n
                        val tapIdx = (offset.x / candleWidth).toInt().coerceIn(0, n - 1)
                        selectedIndex = tapIdx
                        onCandleSelected?.invoke(visibleCandles[tapIdx])
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize().testTag("forecast_chart_canvas")) {
                val width = size.width
                val totalHeight = size.height
                val chartHeight = if (showVolume) totalHeight * 0.78f else totalHeight
                val volumeHeight = if (showVolume) totalHeight * 0.22f else 0f

                fun priceToY(price: Double): Float {
                    val norm = if (isLogScale) {
                        (ln(price) - ln(yMin)) / (ln(yMax) - ln(yMin))
                    } else {
                        (price - yMin) / (yMax - yMin)
                    }
                    return (chartHeight - (norm * chartHeight)).toFloat().coerceIn(0f, chartHeight)
                }

                // 1. Draw horizontal grid lines and price labels
                val gridSteps = 4
                for (i in 0..gridSteps) {
                    val p = yMin + (yMax - yMin) * (i.toDouble() / gridSteps)
                    val y = priceToY(p)
                    drawLine(
                        color = Color.Gray.copy(alpha = 0.15f),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1f
                    )
                }

                val n = visibleCandles.size
                val stepX = width / n
                val candleWidth = max(2f, stepX * 0.65f)

                // 2. Bollinger Bands (O(1) lookups)
                if (bollingerBands.isNotEmpty()) {
                    val upperPath = Path()
                    val lowerPath = Path()
                    var started = false
                    for (i in 0 until n) {
                        val c = visibleCandles[i]
                        val bb = bbMap[c.timestamp]
                        if (bb != null) {
                            val x = i * stepX + stepX / 2f
                            val yUpper = priceToY(bb.upper)
                            val yLower = priceToY(bb.lower)
                            if (!started) {
                                upperPath.moveTo(x, yUpper)
                                lowerPath.moveTo(x, yLower)
                                started = true
                            } else {
                                upperPath.lineTo(x, yUpper)
                                lowerPath.lineTo(x, yLower)
                            }
                        }
                    }
                    drawPath(upperPath, Color(0xFF6366F1).copy(alpha = 0.5f), style = Stroke(width = 1.5f))
                    drawPath(lowerPath, Color(0xFF6366F1).copy(alpha = 0.5f), style = Stroke(width = 1.5f))
                }

                // 3. SMA & EMA Lines (O(1) lookups)
                if (smaPoints.isNotEmpty()) {
                    val smaPath = Path()
                    var started = false
                    for (i in 0 until n) {
                        val c = visibleCandles[i]
                        val pt = smaMap[c.timestamp]
                        if (pt != null) {
                            val x = i * stepX + stepX / 2f
                            val y = priceToY(pt.value)
                            if (!started) { smaPath.moveTo(x, y); started = true } else { smaPath.lineTo(x, y) }
                        }
                    }
                    drawPath(smaPath, Color(0xFFF59E0B), style = Stroke(width = 2f))
                }

                if (emaPoints.isNotEmpty()) {
                    val emaPath = Path()
                    var started = false
                    for (i in 0 until n) {
                        val c = visibleCandles[i]
                        val pt = emaMap[c.timestamp]
                        if (pt != null) {
                            val x = i * stepX + stepX / 2f
                            val y = priceToY(pt.value)
                            if (!started) { emaPath.moveTo(x, y); started = true } else { emaPath.lineTo(x, y) }
                        }
                    }
                    drawPath(emaPath, Color(0xFF06B6D4), style = Stroke(width = 2f))
                }

                // 4. Primary Chart Modes
                var forecastBoundaryX: Float? = null
                var lastActualPoint: Offset? = null

                when (chartType) {
                    ChartType.DUAL_COMPARISON -> {
                        // High Performance Smooth Dual Curve (Actual vs Kronos Price)
                        val actualPath = Path()
                        val forecastPath = Path()
                        val forecastSpreadPath = Path()
                        val actualPoints = ArrayList<Offset>()
                        val forecastPoints = ArrayList<Offset>()
                        val spreadUpperPoints = ArrayList<Offset>()
                        val spreadLowerPoints = ArrayList<Offset>()

                        for (i in 0 until n) {
                            val candle = visibleCandles[i]
                            val x = i * stepX + stepX / 2f
                            val y = priceToY(candle.close)
                            val pt = Offset(x, y)

                            if (candle.isForecast) {
                                if (forecastBoundaryX == null && i > 0) {
                                    forecastBoundaryX = i * stepX
                                }
                                forecastPoints.add(pt)

                                // Spread envelope
                                val upperY = priceToY(candle.spreadUpper ?: candle.high)
                                val lowerY = priceToY(candle.spreadLower ?: candle.low)
                                spreadUpperPoints.add(Offset(x, upperY))
                                spreadLowerPoints.add(Offset(x, lowerY))
                            } else {
                                actualPoints.add(pt)
                                lastActualPoint = pt
                            }

                            // Volume bars
                            if (showVolume && maxVolume > 0) {
                                val vHeight = ((candle.volume / maxVolume) * volumeHeight * 0.85f).toFloat()
                                val vColor = if (candle.isForecast) {
                                    KronosForecastColor.copy(alpha = 0.25f)
                                } else {
                                    if (candle.isBullish) KronosBullish.copy(alpha = 0.35f) else KronosBearish.copy(alpha = 0.35f)
                                }
                                drawRect(
                                    color = vColor,
                                    topLeft = Offset(x - candleWidth / 2f, totalHeight - vHeight),
                                    size = Size(candleWidth, vHeight)
                                )
                            }
                        }

                        // Connect last actual point to first forecast point for seamless continuity
                        lastActualPoint?.let { lap ->
                            if (forecastPoints.isNotEmpty()) {
                                forecastPoints.add(0, lap)
                                spreadUpperPoints.add(0, lap)
                                spreadLowerPoints.add(0, lap)
                            }
                        }

                        // A. Draw Forecast Confidence Spread Ribbon / Cloud
                        if (spreadUpperPoints.size >= 2) {
                            forecastSpreadPath.moveTo(spreadUpperPoints[0].x, spreadUpperPoints[0].y)
                            for (k in 1 until spreadUpperPoints.size) {
                                val p0 = spreadUpperPoints[k - 1]
                                val p1 = spreadUpperPoints[k]
                                val cx = (p0.x + p1.x) / 2f
                                forecastSpreadPath.cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
                            }
                            for (k in spreadLowerPoints.indices.reversed()) {
                                val p = spreadLowerPoints[k]
                                forecastSpreadPath.lineTo(p.x, p.y)
                            }
                            forecastSpreadPath.close()
                            drawPath(forecastSpreadPath, KronosForecastColor.copy(alpha = 0.15f))
                        }

                        // B. Draw Actual Price Line (Solid Glowing Cyan/Blue)
                        if (actualPoints.isNotEmpty()) {
                            actualPath.moveTo(actualPoints[0].x, actualPoints[0].y)
                            for (k in 1 until actualPoints.size) {
                                val p0 = actualPoints[k - 1]
                                val p1 = actualPoints[k]
                                val cx = (p0.x + p1.x) / 2f
                                actualPath.cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
                            }
                            // Area gradient for actual price
                            val actualArea = Path().apply {
                                addPath(actualPath)
                                lineTo(actualPoints.last().x, chartHeight)
                                lineTo(actualPoints.first().x, chartHeight)
                                close()
                            }
                            drawPath(actualArea, Color(0xFF0284C7).copy(alpha = 0.10f))
                            drawPath(actualPath, Color(0xFF38BDF8), style = Stroke(width = 3.0f))

                            // Glow effect for actual line
                            drawPath(actualPath, Color(0xFF38BDF8).copy(alpha = 0.35f), style = Stroke(width = 6.0f))

                            // Real-time pulse dot on the latest live actual price point
                            lastActualPoint?.let { lap ->
                                drawCircle(Color(0xFF38BDF8).copy(alpha = 0.3f), radius = 9f, center = lap)
                                drawCircle(Color.White, radius = 4f, center = lap)
                                drawCircle(Color(0xFF0284C7), radius = 2.5f, center = lap)
                            }
                        }

                        // C. Draw Kronos Forecast Path (Dashed Amber/Gold Path)
                        if (forecastPoints.size >= 2) {
                            forecastPath.moveTo(forecastPoints[0].x, forecastPoints[0].y)
                            for (k in 1 until forecastPoints.size) {
                                val p0 = forecastPoints[k - 1]
                                val p1 = forecastPoints[k]
                                val cx = (p0.x + p1.x) / 2f
                                forecastPath.cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
                            }
                            drawPath(
                                forecastPath,
                                KronosForecastColor,
                                style = Stroke(
                                    width = 3.0f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                                )
                            )

                            // Highlight endpoint of the forecast
                            val finalPt = forecastPoints.last()
                            drawCircle(KronosForecastColor.copy(alpha = 0.4f), radius = 8f, center = finalPt)
                            drawCircle(KronosForecastColor, radius = 4.5f, center = finalPt)
                            drawCircle(Color.White, radius = 2f, center = finalPt)
                        }
                    }

                    ChartType.CANDLESTICK -> {
                        for (i in 0 until n) {
                            val candle = visibleCandles[i]
                            val centerX = i * stepX + stepX / 2f
                            val topY = priceToY(max(candle.open, candle.close))
                            val bottomY = priceToY(min(candle.open, candle.close))
                            val highY = priceToY(candle.high)
                            val lowY = priceToY(candle.low)

                            val isUp = candle.close >= candle.open
                            val candleColor = if (candle.isForecast) {
                                if (isUp) KronosForecastColor else Color(0xFFD97706)
                            } else {
                                if (isUp) KronosBullish else KronosBearish
                            }

                            if (candle.isForecast && forecastBoundaryX == null && i > 0) {
                                forecastBoundaryX = i * stepX
                            }

                            if (candle.isForecast && candle.spreadLower != null && candle.spreadUpper != null) {
                                val sTop = priceToY(candle.spreadUpper)
                                val sBottom = priceToY(candle.spreadLower)
                                drawRect(
                                    color = KronosForecastColor.copy(alpha = 0.15f),
                                    topLeft = Offset(i * stepX, sTop),
                                    size = Size(stepX, max(2f, sBottom - sTop))
                                )
                            }

                            // Wick
                            drawLine(
                                color = candleColor,
                                start = Offset(centerX, highY),
                                end = Offset(centerX, lowY),
                                strokeWidth = 1.5f
                            )

                            // Body
                            val bodyHeight = max(2f, bottomY - topY)
                            drawRect(
                                color = candleColor,
                                topLeft = Offset(centerX - candleWidth / 2f, topY),
                                size = Size(candleWidth, bodyHeight)
                            )

                            // Volume
                            if (showVolume && maxVolume > 0) {
                                val vHeight = ((candle.volume / maxVolume) * volumeHeight * 0.85f).toFloat()
                                val vColor = if (candle.isForecast) {
                                    KronosForecastColor.copy(alpha = 0.35f)
                                } else {
                                    if (isUp) KronosBullish.copy(alpha = 0.35f) else KronosBearish.copy(alpha = 0.35f)
                                }
                                drawRect(
                                    color = vColor,
                                    topLeft = Offset(centerX - candleWidth / 2f, totalHeight - vHeight),
                                    size = Size(candleWidth, vHeight)
                                )
                            }
                        }
                    }

                    ChartType.LINE, ChartType.AREA -> {
                        val linePath = Path()
                        var started = false
                        for (i in 0 until n) {
                            val candle = visibleCandles[i]
                            val x = i * stepX + stepX / 2f
                            val y = priceToY(candle.close)
                            if (!started) { linePath.moveTo(x, y); started = true } else { linePath.lineTo(x, y) }
                            if (candle.isForecast && forecastBoundaryX == null && i > 0) {
                                forecastBoundaryX = i * stepX
                            }
                        }
                        if (chartType == ChartType.AREA) {
                            val areaPath = Path().apply {
                                addPath(linePath)
                                lineTo(n * stepX - stepX / 2f, chartHeight)
                                lineTo(stepX / 2f, chartHeight)
                                close()
                            }
                            drawPath(areaPath, KronosActualColor.copy(alpha = 0.15f))
                        }
                        drawPath(linePath, KronosActualColor, style = Stroke(width = 2.5f))
                    }
                }

                // 5. Draw "FORECAST START" Vertical Boundary Line
                forecastBoundaryX?.let { fX ->
                    val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                    drawLine(
                        color = KronosForecastColor,
                        start = Offset(fX, 0f),
                        end = Offset(fX, chartHeight),
                        strokeWidth = 2f,
                        pathEffect = pathEffect
                    )
                }

                // 6. Crosshair if candle selected
                selectedIndex?.let { idx ->
                    if (idx in visibleCandles.indices) {
                        val cX = idx * stepX + stepX / 2f
                        val cY = priceToY(visibleCandles[idx].close)
                        drawLine(
                            color = Color.Gray.copy(alpha = 0.5f),
                            start = Offset(cX, 0f),
                            end = Offset(cX, totalHeight),
                            strokeWidth = 1f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                        )
                        drawLine(
                            color = Color.Gray.copy(alpha = 0.5f),
                            start = Offset(0f, cY),
                            end = Offset(width, cY),
                            strokeWidth = 1f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                        )
                    }
                }
            }

            // FORECAST START badge
            visibleCandles.firstOrNull { it.isForecast }?.let {
                Surface(
                    color = KronosForecastColor.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .padding(8.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Text(
                        "FORECAST ZONE",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.Black
                    )
                }
            }
        }
    }
}

@Composable
fun CandleInspectorBanner(
    candle: Candle,
    dateFormat: SimpleDateFormat,
    onClose: () -> Unit
) {
    val dateStr = remember(candle.timestamp) { dateFormat.format(Date(candle.timestamp)) }
    Surface(
        color = if (candle.isForecast) KronosForecastBg else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (candle.isForecast) KronosForecastColor else MaterialTheme.colorScheme.outline),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (candle.isForecast) "FORECAST CANDLE" else "ACTUAL CANDLE",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (candle.isForecast) Color(0xFFB45309) else MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(dateStr, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                    "O: ${String.format("%.2f", candle.open)}  H: ${String.format("%.2f", candle.high)}  " +
                            "L: ${String.format("%.2f", candle.low)}  C: ${String.format("%.2f", candle.close)}  " +
                            "(${if (candle.changePercent >= 0) "+" else ""}${String.format("%.2f", candle.changePercent)}%)",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = if (candle.isBullish) KronosBullish else KronosBearish
                )
            }
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close inspector", modifier = Modifier.size(16.dp))
            }
        }
    }
}
