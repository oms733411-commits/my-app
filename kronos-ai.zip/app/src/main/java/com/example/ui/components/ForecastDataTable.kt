package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.Candle
import com.example.ui.theme.KronosBullish
import com.example.ui.theme.KronosBearish
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ForecastDataTable(
    forecastCandles: List<Candle>,
    symbol: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US) }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "PREDICTED OHLCV DATA (${forecastCandles.size} candles)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )

                Row {
                    // Copy
                    IconButton(
                        onClick = {
                            val sb = StringBuilder()
                            sb.append("Timestamp,Open,High,Low,Close,Volume\n")
                            for (c in forecastCandles) {
                                sb.append("${dateFormat.format(Date(c.timestamp))},${c.open},${c.high},${c.low},${c.close},${c.volume}\n")
                            }
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Kronos Forecast CSV", sb.toString()))
                            Toast.makeText(context, "Forecast CSV copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy table", modifier = Modifier.size(18.dp))
                    }

                    // Share
                    IconButton(
                        onClick = {
                            val sb = StringBuilder()
                            sb.append("KRONOS AI Forecast for $symbol\n\n")
                            sb.append("Step | Time | Open | High | Low | Close | Change%\n")
                            for (i in forecastCandles.indices) {
                                val c = forecastCandles[i]
                                sb.append("${i + 1} | ${dateFormat.format(Date(c.timestamp))} | ${String.format("%.2f", c.open)} | ${String.format("%.2f", c.high)} | ${String.format("%.2f", c.low)} | ${String.format("%.2f", c.close)} | ${String.format("%.2f", c.changePercent)}%\n")
                            }
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Kronos Forecast: $symbol")
                                putExtra(Intent.EXTRA_TEXT, sb.toString())
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Forecast"))
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share table", modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Horizontal scrolling table
            val scrollState = rememberScrollState()
            Column(modifier = Modifier.horizontalScroll(scrollState)) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    TableCell("#", width = 36.dp, isHeader = true)
                    TableCell("Time", width = 130.dp, isHeader = true)
                    TableCell("Open", width = 80.dp, isHeader = true)
                    TableCell("High", width = 80.dp, isHeader = true)
                    TableCell("Low", width = 80.dp, isHeader = true)
                    TableCell("Close", width = 80.dp, isHeader = true)
                    TableCell("Change %", width = 80.dp, isHeader = true)
                    TableCell("Volume", width = 90.dp, isHeader = true)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline)

                // Table Rows
                forecastCandles.forEachIndexed { index, c ->
                    val isBullish = c.close >= c.open
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TableCell("${index + 1}", width = 36.dp)
                        TableCell(dateFormat.format(Date(c.timestamp)), width = 130.dp)
                        TableCell(String.format("%.2f", c.open), width = 80.dp)
                        TableCell(String.format("%.2f", c.high), width = 80.dp)
                        TableCell(String.format("%.2f", c.low), width = 80.dp)
                        TableCell(
                            String.format("%.2f", c.close),
                            width = 80.dp,
                            color = if (isBullish) KronosBullish else KronosBearish,
                            fontWeight = FontWeight.SemiBold
                        )
                        TableCell(
                            "${if (c.changePercent >= 0) "+" else ""}${String.format("%.2f", c.changePercent)}%",
                            width = 80.dp,
                            color = if (isBullish) KronosBullish else KronosBearish
                        )
                        TableCell(String.format("%,.0f", c.volume), width = 90.dp)
                    }
                    if (index < forecastCandles.size - 1) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    }
                }
            }
        }
    }
}

@Composable
private fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    isHeader: Boolean = false,
    color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface,
    fontWeight: FontWeight? = null
) {
    Box(modifier = Modifier.width(width).padding(horizontal = 4.dp)) {
        Text(
            text = text,
            style = if (isHeader) MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
            else MaterialTheme.typography.bodySmall,
            color = if (isHeader) MaterialTheme.colorScheme.onSurfaceVariant else color,
            fontWeight = fontWeight ?: if (isHeader) FontWeight.Bold else FontWeight.Normal
        )
    }
}
