package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.data.MarketRegistry
import com.example.core.database.ForecastEntity
import com.example.core.model.Timeframe
import com.example.ui.KronosViewModel
import com.example.ui.theme.KronosBearish
import com.example.ui.theme.KronosBullish
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen(
    viewModel: KronosViewModel,
    onNavigateToForecast: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val historyList by viewModel.allForecastHistory.collectAsState()
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "FORECAST HISTORY",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        "${historyList.size} stored forecast records in local database",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (historyList.isNotEmpty()) {
                    IconButton(
                        onClick = {
                            val sb = StringBuilder()
                            sb.append("ID,Symbol,Market,Timeframe,Date,Horizon,LastClose,PredictedFinalClose,Change%,Direction\n")
                            for (f in historyList) {
                                sb.append("${f.id},${f.symbol},${f.market},${f.timeframe},${dateFormat.format(Date(f.forecastDate))},${f.horizon},${f.lastActualClose},${f.finalForecastClose},${f.forecastChangePercent},${f.direction}\n")
                            }
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Kronos Forecast History", sb.toString()))
                            Toast.makeText(context, "History CSV copied to clipboard", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy History CSV")
                    }
                }
            }
        }

        if (historyList.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "No forecast records saved yet. Run forecasts from the Home or Forecast workspace to build history.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(historyList) { f ->
                HistoryItemCard(
                    forecast = f,
                    dateFormat = dateFormat,
                    onClick = {
                        val inst = MarketRegistry.findBySymbol(f.symbol) ?: viewModel.selectedInstrument.value
                        viewModel.selectInstrument(inst)
                        viewModel.selectTimeframe(Timeframe.fromLabel(f.timeframe))
                        viewModel.horizon.value = f.horizon
                        onNavigateToForecast()
                    }
                )
            }
        }
    }
}

@Composable
private fun HistoryItemCard(
    forecast: ForecastEntity,
    dateFormat: SimpleDateFormat,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(forecast.symbol, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            "${forecast.timeframe} • ${forecast.horizon}b",
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    dateFormat.format(Date(forecast.forecastDate)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Model: ${forecast.modelName} • Close: ${String.format("%.2f", forecast.lastActualClose)} → ${String.format("%.2f", forecast.finalForecastClose)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "${if (forecast.forecastChangePercent >= 0) "+" else ""}${String.format("%.2f", forecast.forecastChangePercent)}%",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (forecast.forecastChangePercent >= 0) KronosBullish else KronosBearish
                )
                Text(
                    forecast.direction,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = if (forecast.forecastChangePercent >= 0) KronosBullish else KronosBearish
                )
            }
        }
    }
}
