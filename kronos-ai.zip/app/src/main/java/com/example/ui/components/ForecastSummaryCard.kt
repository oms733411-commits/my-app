package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.analytics.ForecastAnalysisData
import com.example.core.analytics.ForecastDirection
import com.example.core.model.KronosModelId
import com.example.ui.theme.*

@Composable
fun ForecastSummaryCard(
    analysis: ForecastAnalysisData,
    modelId: KronosModelId,
    horizon: Int,
    currencySymbol: String = "",
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "KRONOS FORECAST SUMMARY",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "Model: ${modelId.displayName} (${modelId.parameterCount} params, 512 ctx)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Direction Badge
                val (dirBg, dirFg, icon) = when (analysis.direction) {
                    ForecastDirection.UP -> Triple(KronosBullishBg, KronosBullish, Icons.Default.ArrowUpward)
                    ForecastDirection.DOWN -> Triple(KronosBearishBg, KronosBearish, Icons.Default.ArrowDownward)
                    ForecastDirection.MIXED -> Triple(Color(0xFFF1F5F9), Color(0xFF475569), Icons.Default.ArrowForward)
                }

                Surface(
                    color = dirBg,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, dirFg.copy(alpha = 0.3f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(icon, contentDescription = null, tint = dirFg, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            analysis.direction.label,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = dirFg
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Main Metrics Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricItem(
                    label = "Last Actual Close",
                    value = "$currencySymbol${String.format("%.2f", analysis.lastActualClose)}"
                )
                MetricItem(
                    label = "Predicted Final Close",
                    value = "$currencySymbol${String.format("%.2f", analysis.forecastFinalClose)}"
                )
                MetricItem(
                    label = "Forecast Change",
                    value = "${if (analysis.forecastChangePercent >= 0) "+" else ""}${String.format("%.2f", analysis.forecastChangePercent)}%",
                    highlightColor = if (analysis.forecastChangePercent >= 0) KronosBullish else KronosBearish
                )
            }

            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            Spacer(Modifier.height(12.dp))

            // Expected Path Row
            Text(
                "Expected Path ($horizon candles):",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "First: $currencySymbol${String.format("%.2f", analysis.firstForecastClose)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Mid: $currencySymbol${String.format("%.2f", analysis.midForecastClose)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Final: $currencySymbol${String.format("%.2f", analysis.forecastFinalClose)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(6.dp))
            Text(
                "Predicted Range: $currencySymbol${String.format("%.2f", analysis.minForecastLow)} - $currencySymbol${String.format("%.2f", analysis.maxForecastHigh)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(8.dp))
            Text(
                analysis.directionBasis,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
private fun MetricItem(
    label: String,
    value: String,
    highlightColor: Color? = null
) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = highlightColor ?: MaterialTheme.colorScheme.onSurface
        )
    }
}
