package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import com.example.ui.KronosViewModel
import com.example.ui.screens.*
import com.example.ui.theme.KronosTheme

enum class AppDestination(val label: String, val icon: ImageVector, val tag: String) {
    HOME("Home", Icons.Default.Home, "home_nav_item"),
    MARKETS("Markets", Icons.Default.ShowChart, "markets_nav_item"),
    FORECAST("Forecast", Icons.Default.TrendingUp, "forecast_nav_item"),
    BACKTEST("Backtest", Icons.Default.Timeline, "backtest_nav_item"),
    HISTORY("History", Icons.Default.History, "history_nav_item"),
    MORE("More", Icons.Default.MoreHoriz, "more_nav_item")
}

class MainActivity : ComponentActivity() {

    private val viewModel: KronosViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            KronosTheme {
                var currentDestination by remember { mutableStateOf(AppDestination.HOME) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.testTag("main_bottom_nav"),
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = NavigationBarDefaults.Elevation
                        ) {
                            AppDestination.entries.forEach { destination ->
                                val selected = currentDestination == destination
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentDestination = destination },
                                    icon = {
                                        Icon(
                                            imageVector = destination.icon,
                                            contentDescription = destination.label
                                        )
                                    },
                                    label = { Text(destination.label) },
                                    modifier = Modifier.testTag(destination.tag)
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    val screenModifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)

                    when (currentDestination) {
                        AppDestination.HOME -> HomeScreen(
                            viewModel = viewModel,
                            onNavigateToForecast = { currentDestination = AppDestination.FORECAST },
                            onNavigateToMarkets = { currentDestination = AppDestination.MARKETS },
                            onNavigateToBacktest = { currentDestination = AppDestination.BACKTEST },
                            onNavigateToMore = { currentDestination = AppDestination.MORE },
                            modifier = screenModifier
                        )
                        AppDestination.MARKETS -> MarketsScreen(
                            viewModel = viewModel,
                            onNavigateToForecast = { currentDestination = AppDestination.FORECAST },
                            modifier = screenModifier
                        )
                        AppDestination.FORECAST -> ForecastScreen(
                            viewModel = viewModel,
                            modifier = screenModifier
                        )
                        AppDestination.BACKTEST -> BacktestScreen(
                            viewModel = viewModel,
                            modifier = screenModifier
                        )
                        AppDestination.HISTORY -> HistoryScreen(
                            viewModel = viewModel,
                            onNavigateToForecast = { currentDestination = AppDestination.FORECAST },
                            modifier = screenModifier
                        )
                        AppDestination.MORE -> MoreScreen(
                            viewModel = viewModel,
                            onNavigateToForecast = { currentDestination = AppDestination.FORECAST },
                            modifier = screenModifier
                        )
                    }
                }
            }
        }
    }
}
