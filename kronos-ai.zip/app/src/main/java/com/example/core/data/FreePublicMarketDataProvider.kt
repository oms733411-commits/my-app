package com.example.core.data

import com.example.core.model.Candle
import com.example.core.model.Timeframe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * 100% Free Public Market Data Provider (Zero-Cost / No API Key required).
 * Supports public Binance Kline endpoints for real-time crypto prices & history,
 * with graceful fallback to Local Quantitative Engine if offline or rate-limited.
 */
object FreePublicMarketDataProvider : MarketDataProvider {

    override val id: String = "free_public_market"
    override val displayName: String = "Free Public Market Feed (Live/Fallback)"
    override val isFree: Boolean = true

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    override suspend fun getHistoricalData(instrument: Instrument, timeframe: Timeframe): List<Candle> {
        return withContext(Dispatchers.IO) {
            try {
                // If it's a crypto pair, try public Binance endpoint (no key required)
                if (instrument.category == MarketCategory.CRYPTO) {
                    val pair = instrument.symbol.replace("/", "").uppercase()
                    val interval = mapTimeframeToBinance(timeframe)
                    val url = "https://api.binance.com/api/v3/klines?symbol=$pair&interval=$interval&limit=180"

                    val request = Request.Builder().url(url).build()
                    httpClient.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            val body = response.body?.string()
                            if (!body.isNullOrBlank()) {
                                val candles = parseBinanceKlines(body)
                                if (candles.isNotEmpty()) {
                                    return@withContext candles
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                // Network unavailable or rate limit -> seamlessly fall back to local quantitative engine
            }

            // Fallback to local quant engine (guarantees offline functionality & ₹0 guarantee)
            DemoDataRepository.getHistoricalData(instrument, timeframe)
        }
    }

    override suspend fun searchInstruments(query: String): List<Instrument> {
        return MarketRegistry.search(query)
    }

    private fun mapTimeframeToBinance(tf: Timeframe): String {
        return when (tf) {
            Timeframe.M1 -> "1m"
            Timeframe.M5 -> "5m"
            Timeframe.M15 -> "15m"
            Timeframe.M30 -> "30m"
            Timeframe.H1 -> "1h"
            Timeframe.H2 -> "2h"
            Timeframe.H4 -> "4h"
            Timeframe.D1 -> "1d"
            Timeframe.W1 -> "1w"
        }
    }

    private fun parseBinanceKlines(jsonString: String): List<Candle> {
        val candles = ArrayList<Candle>()
        try {
            val arr = org.json.JSONArray(jsonString)
            for (i in 0 until arr.length()) {
                val row = arr.getJSONArray(i)
                val openTime = row.getLong(0)
                val open = row.getString(1).toDouble()
                val high = row.getString(2).toDouble()
                val low = row.getString(3).toDouble()
                val close = row.getString(4).toDouble()
                val volume = row.getString(5).toDouble()

                candles.add(
                    Candle(
                        timestamp = openTime,
                        open = open,
                        high = high,
                        low = low,
                        close = close,
                        volume = volume,
                        isForecast = false
                    )
                )
            }
        } catch (_: Exception) {}
        return candles
    }
}
