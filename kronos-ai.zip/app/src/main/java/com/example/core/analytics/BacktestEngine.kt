package com.example.core.analytics

import com.example.core.model.Candle
import com.example.core.model.KronosModelId
import com.example.core.model.KronosPredictor
import com.example.core.model.Timeframe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import kotlin.math.abs
import kotlin.math.sqrt

data class BacktestWindowResult(
    val windowIndex: Int,
    val splitTimestamp: Long,
    val actualCandles: List<Candle>,
    val kronosPredictions: List<Candle>,
    val naivePredictions: List<Candle>,
    val kronosMae: Double,
    val naiveMae: Double,
    val directionalMatch: Boolean
)

data class BacktestMetrics(
    val mae: Double,
    val rmse: Double,
    val mape: Double,
    val directionalAccuracyPercent: Double
)

data class BacktestReport(
    val instrumentSymbol: String,
    val timeframe: Timeframe,
    val lookback: Int,
    val horizon: Int,
    val numWindows: Int,
    val stride: Int,
    val modelId: KronosModelId,
    val kronosMetrics: BacktestMetrics,
    val naiveMetrics: BacktestMetrics,
    val windowResults: List<BacktestWindowResult>,
    val executionTimeMs: Long
)

object BacktestEngine {

    /**
     * Executes real Walk-Forward rolling backtest without data leakage.
     */
    suspend fun runWalkForwardBacktest(
        dataset: List<Candle>,
        instrumentSymbol: String,
        timeframe: Timeframe,
        lookback: Int = 60,
        horizon: Int = 10,
        numWindows: Int = 5,
        stride: Int = 10,
        modelId: KronosModelId = KronosModelId.KRONOS_BASE,
        onProgress: ((currentWindow: Int, totalWindows: Int) -> Unit)? = null
    ): BacktestReport = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        val totalNeeded = lookback + (numWindows - 1) * stride + horizon
        if (dataset.size < totalNeeded) {
            throw IllegalArgumentException(
                "Insufficient candles for $numWindows windows (lookback: $lookback, horizon: $horizon, stride: $stride). " +
                        "Requires $totalNeeded candles, but dataset only has ${dataset.size}."
            )
        }

        val predictor = KronosPredictor(modelId)
        val windowResults = ArrayList<BacktestWindowResult>()

        var sumKronosAe = 0.0
        var sumKronosSe = 0.0
        var sumKronosApe = 0.0
        var kronosDirCorrect = 0

        var sumNaiveAe = 0.0
        var sumNaiveSe = 0.0
        var sumNaiveApe = 0.0
        var naiveDirCorrect = 0

        var totalPredictionPoints = 0

        val startOffset = dataset.size - totalNeeded

        for (w in 0 until numWindows) {
            yield()
            onProgress?.invoke(w + 1, numWindows)

            val splitIdx = startOffset + lookback + (w * stride)
            val historicalSlice = dataset.subList(splitIdx - lookback, splitIdx)
            val actualFutureSlice = dataset.subList(splitIdx, splitIdx + horizon)

            val lastActualClose = historicalSlice.last().close
            val actualFinalClose = actualFutureSlice.last().close
            val actualDirUp = actualFinalClose >= lastActualClose

            // Run Kronos inference on historical context ONLY (Zero leakage)
            val forecastResult = predictor.predict(
                historicalData = historicalSlice,
                timeframe = timeframe,
                lookback = lookback,
                horizon = horizon,
                temperature = 0.0f // Deterministic comparison
            )
            val kronosFuture = forecastResult.forecastCandles
            val kronosFinalClose = kronosFuture.last().close
            val kronosDirUp = kronosFinalClose >= lastActualClose
            val dirMatch = (kronosDirUp == actualDirUp)
            if (dirMatch) kronosDirCorrect++

            // Naive baseline predictions (Persistence: pred = lastActualClose)
            val naiveFuture = actualFutureSlice.map {
                it.copy(
                    open = lastActualClose,
                    high = lastActualClose,
                    low = lastActualClose,
                    close = lastActualClose,
                    isForecast = true
                )
            }
            // Naive direction is flat/mixed (counted as neutral)

            var wKronosAe = 0.0
            var wNaiveAe = 0.0

            for (h in 0 until horizon) {
                val act = actualFutureSlice[h].close
                val kronosPred = kronosFuture[h].close
                val naivePred = lastActualClose

                val kErr = abs(kronosPred - act)
                val nErr = abs(naivePred - act)

                wKronosAe += kErr
                wNaiveAe += nErr

                sumKronosAe += kErr
                sumKronosSe += kErr * kErr
                sumKronosApe += if (act != 0.0) (kErr / act) else 0.0

                sumNaiveAe += nErr
                sumNaiveSe += nErr * nErr
                sumNaiveApe += if (act != 0.0) (nErr / act) else 0.0

                totalPredictionPoints++
            }

            windowResults.add(
                BacktestWindowResult(
                    windowIndex = w + 1,
                    splitTimestamp = dataset[splitIdx].timestamp,
                    actualCandles = actualFutureSlice,
                    kronosPredictions = kronosFuture,
                    naivePredictions = naiveFuture,
                    kronosMae = wKronosAe / horizon,
                    naiveMae = wNaiveAe / horizon,
                    directionalMatch = dirMatch
                )
            )
        }

        val totalPts = maxOf(1, totalPredictionPoints)
        val kMae = sumKronosAe / totalPts
        val kRmse = sqrt(sumKronosSe / totalPts)
        val kMape = (sumKronosApe / totalPts) * 100.0
        val kDirAcc = (kronosDirCorrect.toDouble() / numWindows) * 100.0

        val nMae = sumNaiveAe / totalPts
        val nRmse = sqrt(sumNaiveSe / totalPts)
        val nMape = (sumNaiveApe / totalPts) * 100.0
        val nDirAcc = 50.0 // Baseline random/flat chance

        val elapsed = System.currentTimeMillis() - startTime

        BacktestReport(
            instrumentSymbol = instrumentSymbol,
            timeframe = timeframe,
            lookback = lookback,
            horizon = horizon,
            numWindows = numWindows,
            stride = stride,
            modelId = modelId,
            kronosMetrics = BacktestMetrics(kMae, kRmse, kMape, kDirAcc),
            naiveMetrics = BacktestMetrics(nMae, nRmse, nMape, nDirAcc),
            windowResults = windowResults,
            executionTimeMs = elapsed
        )
    }
}
