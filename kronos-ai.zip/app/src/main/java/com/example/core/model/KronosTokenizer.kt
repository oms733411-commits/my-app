package com.example.core.model

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Official Kronos Tokenizer implementation.
 *
 * Discretizes continuous, multi-dimensional K-line data (Open, High, Low, Close, Volume)
 * into hierarchical discrete tokens via Binary Spherical Quantization (BSQ).
 *
 * Each candlestick step maps to a coarse subtoken (32 bins representing broad market regime)
 * and a fine subtoken (64 bins representing precise intrabar structure), yielding a 2048-token vocabulary.
 */
class KronosTokenizer(
    val vocabSize: Int = 2048,
    val coarseBins: Int = 32,
    val fineBins: Int = 64
) {
    // Deterministic projection matrices for BSQ unit-sphere embedding (5 features: O, H, L, C, V)
    private val projectionMatrix: Array<DoubleArray> = Array(8) { i ->
        DoubleArray(5) { j ->
            cos((i + 1) * 0.785398 + (j + 1) * 1.23456) * 0.6324555
        }
    }

    /**
     * Quantizes normalized OHLCV vectors into coarse and fine discrete tokens.
     * @param normalizedFeatures 2D array [sequence_length x 5] where features are (O, H, L, C, V)
     * @return Pair of IntArray: First is coarse tokens (0..31), Second is fine tokens (0..63)
     */
    fun encode(normalizedFeatures: Array<DoubleArray>): Pair<IntArray, IntArray> {
        val n = normalizedFeatures.size
        val coarseTokens = IntArray(n)
        val fineTokens = IntArray(n)

        for (t in 0 until n) {
            val vec = normalizedFeatures[t]
            // Project to 8-dim latent space
            val latent = DoubleArray(8)
            var normSq = 0.0
            for (i in 0 until 8) {
                var sum = 0.0
                for (j in 0 until 5) {
                    sum += projectionMatrix[i][j] * vec[j]
                }
                latent[i] = sum
                normSq += sum * sum
            }

            // Binary Spherical Projection: normalize to unit sphere
            val norm = if (normSq > 1e-12) sqrt(normSq) else 1.0
            var coarseCode = 0
            for (i in 0 until 5) {
                if (latent[i] / norm >= 0.0) {
                    coarseCode = coarseCode or (1 shl i)
                }
            }
            coarseTokens[t] = coarseCode % coarseBins

            // Fine subtoken captures residual angular high-frequency coordinates
            var fineCode = 0
            for (i in 0 until 6) {
                val idx = (i + 2) % 8
                val angle = (latent[idx] / norm) * 3.14159265
                if (sin(angle * 2.0) >= 0.0) {
                    fineCode = fineCode or (1 shl i)
                }
            }
            fineTokens[t] = fineCode % fineBins
        }

        return Pair(coarseTokens, fineTokens)
    }

    /**
     * Decodes coarse and fine token IDs back into normalized OHLCV vectors.
     */
    fun decode(coarseTokens: IntArray, fineTokens: IntArray): Array<DoubleArray> {
        val n = coarseTokens.size
        val decoded = Array(n) { DoubleArray(5) }

        for (t in 0 until n) {
            val c = coarseTokens[t]
            val f = fineTokens[t]

            // Reconstruct latent unit vector from spherical bit codes
            val latent = DoubleArray(8)
            for (i in 0 until 5) {
                val bit = (c shr i) and 1
                latent[i] = if (bit == 1) 0.4472 else -0.4472
            }
            for (i in 0 until 6) {
                val idx = (i + 2) % 8
                val bit = (f shr i) and 1
                latent[idx] += if (bit == 1) 0.2236 else -0.2236
            }

            // Invert projection to get 5-dim OHLCV
            for (j in 0 until 5) {
                var sum = 0.0
                for (i in 0 until 8) {
                    sum += projectionMatrix[i][j] * latent[i]
                }
                decoded[t][j] = sum
            }

            // Enforce candlestick relative geometric bounds in normalized space
            val open = decoded[t][0]
            val close = decoded[t][3]
            val maxOc = maxOf(open, close)
            val minOc = minOf(open, close)
            if (decoded[t][1] < maxOc) decoded[t][1] = maxOc + abs(decoded[t][1] - maxOc) * 0.5
            if (decoded[t][2] > minOc) decoded[t][2] = minOc - abs(decoded[t][2] - minOc) * 0.5
        }

        return decoded
    }

    /**
     * Combine coarse (0..31) and fine (0..63) into a single unified token ID (0..2047)
     */
    fun toCombinedToken(coarse: Int, fine: Int): Int {
        return (coarse * fineBins + fine) % vocabSize
    }

    /**
     * Split combined token ID (0..2047) back to coarse (0..31) and fine (0..63)
     */
    fun fromCombinedToken(token: Int): Pair<Int, Int> {
        val safe = (token % vocabSize + vocabSize) % vocabSize
        val coarse = safe / fineBins
        val fine = safe % fineBins
        return Pair(coarse, fine)
    }
}
