package com.example.core.analytics

import com.example.core.model.Candle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class IndicatorPoint(
    val timestamp: Long,
    val value: Double
)

data class BollingerBandPoint(
    val timestamp: Long,
    val upper: Double,
    val middle: Double,
    val lower: Double
)

data class MacdPoint(
    val timestamp: Long,
    val macd: Double,
    val signal: Double,
    val histogram: Double
)

object TechnicalIndicators {

    fun calculateSMA(candles: List<Candle>, period: Int = 20): List<IndicatorPoint> {
        if (candles.size < period) return emptyList()
        val result = ArrayList<IndicatorPoint>()
        var sum = 0.0
        for (i in candles.indices) {
            sum += candles[i].close
            if (i >= period) {
                sum -= candles[i - period].close
            }
            if (i >= period - 1) {
                result.add(IndicatorPoint(candles[i].timestamp, sum / period))
            }
        }
        return result
    }

    fun calculateEMA(candles: List<Candle>, period: Int = 20): List<IndicatorPoint> {
        if (candles.size < period) return emptyList()
        val result = ArrayList<IndicatorPoint>()
        val multiplier = 2.0 / (period + 1.0)

        var initialSma = 0.0
        for (i in 0 until period) {
            initialSma += candles[i].close
        }
        var currentEma = initialSma / period
        result.add(IndicatorPoint(candles[period - 1].timestamp, currentEma))

        for (i in period until candles.size) {
            currentEma = (candles[i].close - currentEma) * multiplier + currentEma
            result.add(IndicatorPoint(candles[i].timestamp, currentEma))
        }
        return result
    }

    fun calculateRSI(candles: List<Candle>, period: Int = 14): List<IndicatorPoint> {
        if (candles.size <= period) return emptyList()
        val result = ArrayList<IndicatorPoint>()

        var gainSum = 0.0
        var lossSum = 0.0

        for (i in 1..period) {
            val diff = candles[i].close - candles[i - 1].close
            if (diff > 0) gainSum += diff else lossSum += abs(diff)
        }

        var avgGain = gainSum / period
        var avgLoss = lossSum / period

        val firstRs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
        val firstRsi = if (avgLoss == 0.0) 100.0 else 100.0 - (100.0 / (1.0 + firstRs))
        result.add(IndicatorPoint(candles[period].timestamp, firstRsi.coerceIn(0.0, 100.0)))

        for (i in (period + 1) until candles.size) {
            val diff = candles[i].close - candles[i - 1].close
            val gain = if (diff > 0) diff else 0.0
            val loss = if (diff < 0) abs(diff) else 0.0

            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period

            val rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
            val rsi = if (avgLoss == 0.0) 100.0 else 100.0 - (100.0 / (1.0 + rs))
            result.add(IndicatorPoint(candles[i].timestamp, rsi.coerceIn(0.0, 100.0)))
        }

        return result
    }

    fun calculateBollingerBands(candles: List<Candle>, period: Int = 20, multiplier: Double = 2.0): List<BollingerBandPoint> {
        if (candles.size < period) return emptyList()
        val result = ArrayList<BollingerBandPoint>()

        for (i in (period - 1) until candles.size) {
            val slice = candles.subList(i - period + 1, i + 1)
            val mean = slice.map { it.close }.average()
            val variance = slice.map { (it.close - mean) * (it.close - mean) }.average()
            val stdDev = sqrt(variance)

            result.add(
                BollingerBandPoint(
                    timestamp = candles[i].timestamp,
                    upper = mean + multiplier * stdDev,
                    middle = mean,
                    lower = mean - multiplier * stdDev
                )
            )
        }
        return result
    }

    fun calculateMACD(candles: List<Candle>): List<MacdPoint> {
        val ema12 = calculateEMA(candles, 12).associateBy { it.timestamp }
        val ema26 = calculateEMA(candles, 26).associateBy { it.timestamp }

        val macdLine = ArrayList<IndicatorPoint>()
        for (c in candles) {
            val e12 = ema12[c.timestamp]?.value
            val e26 = ema26[c.timestamp]?.value
            if (e12 != null && e26 != null) {
                macdLine.add(IndicatorPoint(c.timestamp, e12 - e26))
            }
        }

        if (macdLine.size < 9) return emptyList()

        // 9-period EMA of MACD line
        val multiplier = 2.0 / 10.0
        var currentSignal = macdLine.take(9).map { it.value }.average()
        val result = ArrayList<MacdPoint>()

        for (i in 8 until macdLine.size) {
            val mVal = macdLine[i].value
            if (i > 8) {
                currentSignal = (mVal - currentSignal) * multiplier + currentSignal
            }
            result.add(
                MacdPoint(
                    timestamp = macdLine[i].timestamp,
                    macd = mVal,
                    signal = currentSignal,
                    histogram = mVal - currentSignal
                )
            )
        }

        return result
    }
}
