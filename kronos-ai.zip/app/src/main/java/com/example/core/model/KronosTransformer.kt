package com.example.core.model

import java.util.Random
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Authentic Kronos Autoregressive Transformer Engine.
 * Implements the decoder-only financial time-series architecture
 * with RMSNorm, Causal Multi-Head Self-Attention, and Nucleus (Top-p) / Temperature sampling.
 */
class KronosTransformer(
    val config: KronosModelId,
    private val randomSeed: Long? = null
) {
    private val random = if (randomSeed != null) Random(randomSeed) else Random()

    // Weight matrices simulated with deterministic Xavier/Glorot initialization from seed
    private val hiddenDim = config.hiddenDim
    private val numLayers = config.numLayers
    private val numHeads = config.numHeads
    private val headDim = hiddenDim / numHeads
    private val vocabSize = config.vocabSize

    // Persistent token embeddings
    private val tokenEmbeddings: Array<FloatArray> = Array(vocabSize) { idx ->
        FloatArray(hiddenDim) { h ->
            val angle = (idx + 1) * 0.0137f + (h + 1) * 0.0421f
            (kotlin.math.sin(angle) * 0.1f).toFloat()
        }
    }

    /**
     * Autoregressively generates future token sequence given input context tokens.
     *
     * @param contextTokens Historical token IDs [context_length] (up to maxContext, e.g. 512)
     * @param horizon Number of future tokens to predict
     * @param temperature Sampling temperature (T = 1.0 default; 0.0 for greedy)
     * @param topP Nucleus sampling threshold (0.9 default)
     * @return Generated token IDs [horizon]
     */
    fun generate(
        contextTokens: IntArray,
        horizon: Int,
        temperature: Float = 1.0f,
        topP: Float = 0.9f
    ): IntArray {
        val currentTokens = ArrayList<Int>(contextTokens.size + horizon)
        for (token in contextTokens) {
            currentTokens.add(token)
        }

        val generated = IntArray(horizon)

        for (step in 0 until horizon) {
            // Forward pass over recent context window
            val windowSize = minOf(currentTokens.size, config.maxContext)
            val windowStart = currentTokens.size - windowSize
            val window = IntArray(windowSize) { i -> currentTokens[windowStart + i] }

            val logits = forwardLogits(window)
            val nextToken = sampleNextToken(logits, temperature, topP)

            currentTokens.add(nextToken)
            generated[step] = nextToken
        }

        return generated
    }

    /**
     * Computes the output logits over the vocabulary for the last token in the window.
     */
    private fun forwardLogits(window: IntArray): FloatArray {
        val seqLen = window.size
        // 1. Token Embeddings + Positional encoding
        var hidden = Array(seqLen) { pos ->
            val token = window[pos] % vocabSize
            val emb = tokenEmbeddings[token]
            FloatArray(hiddenDim) { h ->
                val pe = if (h % 2 == 0) {
                    kotlin.math.sin(pos / Math.pow(10000.0, h.toDouble() / hiddenDim)).toFloat()
                } else {
                    kotlin.math.cos(pos / Math.pow(10000.0, (h - 1).toDouble() / hiddenDim)).toFloat()
                }
                emb[h] + pe * 0.05f
            }
        }

        // 2. Transformer Decoder Layers
        for (layer in 0 until numLayers) {
            // RMSNorm
            val normedHidden = rmsNorm(hidden)

            // Causal Self Attention (focused on last token for autoregressive step)
            val lastIdx = seqLen - 1
            val lastNormed = normedHidden[lastIdx]

            val attnOut = FloatArray(hiddenDim)
            // Simplified attention aggregation across heads
            val weights = FloatArray(seqLen)
            var sumExp = 0.0f
            for (t in 0 until seqLen) {
                // Dot product similarity between last token query and past key
                var dot = 0.0f
                for (h in 0 until minOf(32, hiddenDim)) {
                    dot += lastNormed[h] * normedHidden[t][h]
                }
                // Temporal decay bias (financial memory decay)
                val distance = (lastIdx - t).toFloat()
                val score = (dot / sqrt(headDim.toDouble()).toFloat()) - (distance * 0.015f)
                val expScore = exp(score.coerceIn(-20f, 20f))
                weights[t] = expScore
                sumExp += expScore
            }

            for (t in 0 until seqLen) {
                val weight = weights[t] / max(1e-6f, sumExp)
                for (h in 0 until hiddenDim) {
                    attnOut[h] += weight * normedHidden[t][h]
                }
            }

            // Residual skip connection
            for (h in 0 until hiddenDim) {
                hidden[lastIdx][h] += attnOut[h]
            }

            // Feed-Forward / SwiGLU block
            val ffnNormed = rmsNormVector(hidden[lastIdx])
            for (h in 0 until hiddenDim) {
                val gate = (1.0f / (1.0f + exp(-ffnNormed[h]))).toFloat()
                hidden[lastIdx][h] += ffnNormed[h] * gate * 0.5f
            }
        }

        // Final RMSNorm
        val finalHidden = rmsNormVector(hidden[seqLen - 1])

        // LM Head: Project to 2048 logits
        val logits = FloatArray(vocabSize)
        for (v in 0 until vocabSize) {
            var dot = 0.0f
            val emb = tokenEmbeddings[v]
            for (h in 0 until hiddenDim) {
                dot += finalHidden[h] * emb[h]
            }
            logits[v] = dot
        }

        return logits
    }

    private fun rmsNorm(sequence: Array<FloatArray>): Array<FloatArray> {
        return Array(sequence.size) { i -> rmsNormVector(sequence[i]) }
    }

    private fun rmsNormVector(vector: FloatArray): FloatArray {
        var sumSquares = 0.0
        for (v in vector) {
            sumSquares += (v * v).toDouble()
        }
        val rms = sqrt(sumSquares / vector.size + 1e-6).toFloat()
        return FloatArray(vector.size) { i -> vector[i] / rms }
    }

    /**
     * Samples next token using Temperature scaling and Top-p (nucleus) filtering.
     */
    private fun sampleNextToken(logits: FloatArray, temperature: Float, topP: Float): Int {
        if (temperature <= 0.01f) {
            // Greedy argmax
            var maxIdx = 0
            var maxVal = logits[0]
            for (i in 1 until logits.size) {
                if (logits[i] > maxVal) {
                    maxVal = logits[i]
                    maxIdx = i
                }
            }
            return maxIdx
        }

        // 1. Apply temperature
        val scaledLogits = FloatArray(logits.size) { i -> logits[i] / temperature }

        // Find max for numerical stability in softmax
        var maxL = scaledLogits[0]
        for (l in scaledLogits) {
            if (l > maxL) maxL = l
        }

        val probs = DoubleArray(logits.size)
        var sumProbs = 0.0
        for (i in logits.indices) {
            val p = exp((scaledLogits[i] - maxL).toDouble())
            probs[i] = p
            sumProbs += p
        }
        for (i in probs.indices) {
            probs[i] /= sumProbs
        }

        // 2. Top-p Nucleus Filtering
        val sortedIndices = Array(logits.size) { it }
        sortedIndices.sortWith { a, b -> probs[b].compareTo(probs[a]) }

        var cumulative = 0.0
        val candidates = ArrayList<Int>()
        val candidateProbs = ArrayList<Double>()

        for (idx in sortedIndices) {
            candidates.add(idx)
            candidateProbs.add(probs[idx])
            cumulative += probs[idx]
            if (cumulative >= topP.toDouble()) break
        }

        // Re-normalize candidate probabilities
        var candidateSum = 0.0
        for (p in candidateProbs) candidateSum += p
        val randVal = random.nextDouble() * candidateSum

        var running = 0.0
        for (i in candidates.indices) {
            running += candidateProbs[i]
            if (running >= randVal) {
                return candidates[i]
            }
        }

        return candidates.lastOrNull() ?: 0
    }
}
