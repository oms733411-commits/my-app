package com.example.core.model

/**
 * Official specifications and configuration for the Kronos Financial Foundation Models
 * Source: https://github.com/shiyu-coder/Kronos
 * HuggingFace: https://huggingface.co/NeoQuasar
 */
enum class KronosModelId(
    val displayName: String,
    val parameterCount: String,
    val parameterCountExact: Long,
    val maxContext: Int,
    val hiddenDim: Int,
    val numLayers: Int,
    val numHeads: Int,
    val vocabSize: Int,
    val downloadSizeMb: Int,
    val requiredRamMb: Int,
    val hfRepoId: String,
    val description: String
) {
    KRONOS_BASE(
        displayName = "Kronos-base",
        parameterCount = "102.3M",
        parameterCountExact = 102_300_000L,
        maxContext = 512,
        hiddenDim = 768,
        numLayers = 12,
        numHeads = 12,
        vocabSize = 2048,
        downloadSizeMb = 196,
        requiredRamMb = 380,
        hfRepoId = "NeoQuasar/Kronos-base",
        description = "Full official foundation model. Recommended for maximum forecasting fidelity."
    ),
    KRONOS_SMALL(
        displayName = "Kronos-small",
        parameterCount = "24.7M",
        parameterCountExact = 24_700_000L,
        maxContext = 512,
        hiddenDim = 384,
        numLayers = 6,
        numHeads = 6,
        vocabSize = 2048,
        downloadSizeMb = 48,
        requiredRamMb = 120,
        hfRepoId = "NeoQuasar/Kronos-small",
        description = "Lightweight official foundation model. Optimized for constrained mobile devices."
    ),
    KRONOS_MINI(
        displayName = "Kronos-mini",
        parameterCount = "4.1M",
        parameterCountExact = 4_100_000L,
        maxContext = 2048,
        hiddenDim = 192,
        numLayers = 4,
        numHeads = 4,
        vocabSize = 2048,
        downloadSizeMb = 9,
        requiredRamMb = 32,
        hfRepoId = "NeoQuasar/Kronos-mini",
        description = "Ultra-compact mobile compatibility model with extended 2048 bar context."
    )
}

data class ModelStatus(
    val activeModel: KronosModelId = KronosModelId.KRONOS_BASE,
    val isInstalled: Boolean = true,
    val isDownloading: Boolean = false,
    val downloadProgress: Float = 1.0f,
    val statusText: String = "Model ready",
    val runtimeName: String = "Kronos Mobile On-Device Engine (XNNPACK/ExecuTorch compatible)",
    val precision: String = "FP32 / BF16",
    val storageUsedMb: Double = 196.0,
    val reason: String? = null
)
