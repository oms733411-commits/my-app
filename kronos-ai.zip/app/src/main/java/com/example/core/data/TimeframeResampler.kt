package com.example.core.data

import com.example.core.model.Candle
import com.example.core.model.Timeframe
import kotlin.math.max
import kotlin.math.min

object TimeframeResampler {

    /**
     * Resamples candles into a higher timeframe using mathematically correct OHLCV aggregation:
     * Open = first, High = max, Low = min, Close = last, Volume = sum
     */
    fun resample(candles: List<Candle>, targetTimeframe: Timeframe): List<Candle> {
        if (candles.isEmpty()) return emptyList()

        val interval = targetTimeframe.intervalMillis
        val groups = candles.groupBy { it.timestamp / interval }
        val resampled = ArrayList<Candle>()

        for ((bucketKey, bucketCandles) in groups.toSortedMap()) {
            if (bucketCandles.isEmpty()) continue
            val first = bucketCandles.first()
            val last = bucketCandles.last()

            var maxH = bucketCandles[0].high
            var minL = bucketCandles[0].low
            var sumV = 0.0

            for (c in bucketCandles) {
                if (c.high > maxH) maxH = c.high
                if (c.low < minL) minL = c.low
                sumV += c.volume
            }

            resampled.add(
                Candle(
                    timestamp = bucketKey * interval,
                    open = first.open,
                    high = maxH,
                    low = minL,
                    close = last.close,
                    volume = sumV
                )
            )
        }

        return resampled
    }
}
