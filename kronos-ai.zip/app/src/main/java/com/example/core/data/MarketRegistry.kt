package com.example.core.data

object MarketRegistry {

    val allInstruments: List<Instrument> = listOf(
        // Indian Indices
        Instrument("NIFTY 50", "Nifty 50 Index", "NSE", MarketCategory.INDIAN_INDICES, "INR", "Asia/Kolkata"),
        Instrument("BANK NIFTY", "Nifty Bank Index", "NSE", MarketCategory.INDIAN_INDICES, "INR", "Asia/Kolkata"),
        Instrument("SENSEX", "BSE Sensex Index", "BSE", MarketCategory.INDIAN_INDICES, "INR", "Asia/Kolkata"),

        // Indian Equities
        Instrument("RELIANCE", "Reliance Industries Ltd", "NSE", MarketCategory.INDIAN_EQUITIES, "INR", "Asia/Kolkata"),
        Instrument("TCS", "Tata Consultancy Services Ltd", "NSE", MarketCategory.INDIAN_EQUITIES, "INR", "Asia/Kolkata"),
        Instrument("INFY", "Infosys Limited", "NSE", MarketCategory.INDIAN_EQUITIES, "INR", "Asia/Kolkata"),
        Instrument("HDFCBANK", "HDFC Bank Ltd", "NSE", MarketCategory.INDIAN_EQUITIES, "INR", "Asia/Kolkata"),
        Instrument("ICICIBANK", "ICICI Bank Ltd", "NSE", MarketCategory.INDIAN_EQUITIES, "INR", "Asia/Kolkata"),

        // US Equities
        Instrument("AAPL", "Apple Inc.", "NASDAQ", MarketCategory.US_EQUITIES, "USD", "America/New_York"),
        Instrument("MSFT", "Microsoft Corporation", "NASDAQ", MarketCategory.US_EQUITIES, "USD", "America/New_York"),
        Instrument("NVDA", "NVIDIA Corporation", "NASDAQ", MarketCategory.US_EQUITIES, "USD", "America/New_York"),
        Instrument("TSLA", "Tesla, Inc.", "NASDAQ", MarketCategory.US_EQUITIES, "USD", "America/New_York"),
        Instrument("GOOGL", "Alphabet Inc.", "NASDAQ", MarketCategory.US_EQUITIES, "USD", "America/New_York"),

        // Crypto
        Instrument("BTC/USDT", "Bitcoin / Tether", "Binance", MarketCategory.CRYPTO, "USDT", "UTC"),
        Instrument("ETH/USDT", "Ethereum / Tether", "Binance", MarketCategory.CRYPTO, "USDT", "UTC"),
        Instrument("SOL/USDT", "Solana / Tether", "Binance", MarketCategory.CRYPTO, "USDT", "UTC"),

        // Forex
        Instrument("EUR/USD", "Euro / US Dollar", "Forex", MarketCategory.FOREX, "USD", "UTC"),
        Instrument("GBP/USD", "British Pound / US Dollar", "Forex", MarketCategory.FOREX, "USD", "UTC"),
        Instrument("USD/INR", "US Dollar / Indian Rupee", "Forex", MarketCategory.FOREX, "INR", "Asia/Kolkata"),

        // Commodities
        Instrument("GOLD", "Gold Spot", "COMEX", MarketCategory.COMMODITIES, "USD", "America/New_York"),
        Instrument("CRUDE", "Brent Crude Oil", "NYMEX", MarketCategory.COMMODITIES, "USD", "America/New_York")
    )

    fun search(query: String): List<Instrument> {
        if (query.isBlank()) return allInstruments
        val q = query.trim().lowercase()
        return allInstruments.filter {
            it.symbol.lowercase().contains(q) ||
                    it.name.lowercase().contains(q) ||
                    it.exchange.lowercase().contains(q)
        }
    }

    fun findBySymbol(symbol: String): Instrument? {
        return allInstruments.firstOrNull { it.symbol.equals(symbol, ignoreCase = true) }
    }
}
