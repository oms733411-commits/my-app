package com.example.core.model

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Result of a Kronos forecast execution.
 */
data class ForecastResult(
    val historicalCandles: List<Candle>,
    val forecastCandles: List<Candle>,
    val modelId: KronosModelId,
    val timeframe: Timeframe,
    val lookbackUsed: Int,
    val horizon: Int,
    val temperature: Float,
    val topP: Float,
    val sampleCount: Int,
    val inferenceTimeMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Stages of Kronos prediction pipeline per Section 61.
 */
sealed class ForecastProgress(val message: String, val step: Int, val totalSteps: Int = 6) {
    object PreparingData : ForecastProgress("Preparing data", 1)
    object Tokenizing : ForecastProgress("Tokenizing", 2)
    object LoadingModel : ForecastProgress("Loading model", 3)
    object RunningInference : ForecastProgress("Running inference", 4)
    object DecodingForecast : ForecastProgress("Decoding forecast", 5)
    object RenderingChart : ForecastProgress("Rendering chart", 6)
}

/**
 * The official KronosPredictor pipeline.
 * Coordinates data normalization, BSQ tokenization, autoregressive Transformer inference,
 * and inverse normalization.
 */
class KronosPredictor(
    private val modelId: KronosModelId = KronosModelId.KRONOS_BASE,
    private val tokenizer: KronosTokenizer = KronosTokenizer()
) {
    /**
     * Executes the complete Kronos forecasting pipeline.
     */
    suspend fun predict(
        historicalData: List<Candle>,
        timeframe: Timeframe,
        lookback: Int = 512,
        horizon: Int = 10,
        temperature: Float = 1.0f,
        topP: Float = 0.9f,
        sampleCount: Int = 1,
        onProgress: ((ForecastProgress) -> Unit)? = null
    ): ForecastResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()

        // 1. Preparing data
        onProgress?.invoke(ForecastProgress.PreparingData)
        yield()
        if (historicalData.isEmpty()) {
            throw IllegalArgumentException("Historical candle dataset is empty.")
        }

        // Use the latest requested lookback, capped at model's maxContext (512 for base/small)
        val effectiveLookback = minOf(lookback, modelId.maxContext, historicalData.size)
        val contextSlice = historicalData.takeLast(effectiveLookback)

        // Calculate statistics for temporal z-score normalization
        val n = contextSlice.size
        var sumO = 0.0; var sumH = 0.0; var sumL = 0.0; var sumC = 0.0; var sumV = 0.0
        for (c in contextSlice) {
            sumO += c.open; sumH += c.high; sumL += c.low; sumC += c.close; sumV += c.volume
        }
        val meanO = sumO / n; val meanH = sumH / n; val meanL = sumL / n; val meanC = sumC / n; val meanV = sumV / n

        var varO = 0.0; var varH = 0.0; var varL = 0.0; var varC = 0.0; var varV = 0.0
        for (c in contextSlice) {
            varO += (c.open - meanO) * (c.open - meanO)
            varH += (c.high - meanH) * (c.high - meanH)
            varL += (c.low - meanL) * (c.low - meanL)
            varC += (c.close - meanC) * (c.close - meanC)
            varV += (c.volume - meanV) * (c.volume - meanV)
        }
        val stdO = max(1e-4, sqrt(varO / n))
        val stdH = max(1e-4, sqrt(varH / n))
        val stdL = max(1e-4, sqrt(varL / n))
        val stdC = max(1e-4, sqrt(varC / n))
        val stdV = max(1e-4, sqrt(varV / n))

        // Normalize features: (x - mean) / std, clipped within [-5.0, 5.0]
        val normalized = Array(n) { i ->
            val c = contextSlice[i]
            doubleArrayOf(
                ((c.open - meanO) / stdO).coerceIn(-5.0, 5.0),
                ((c.high - meanH) / stdH).coerceIn(-5.0, 5.0),
                ((c.low - meanL) / stdL).coerceIn(-5.0, 5.0),
                ((c.close - meanC) / stdC).coerceIn(-5.0, 5.0),
                ((c.volume - meanV) / stdV).coerceIn(-5.0, 5.0)
            )
        }

        // 2. Tokenizing
        onProgress?.invoke(ForecastProgress.Tokenizing)
        yield()
        val (coarseTokens, fineTokens) = tokenizer.encode(normalized)
        val combinedTokens = IntArray(n) { i ->
            tokenizer.toCombinedToken(coarseTokens[i], fineTokens[i])
        }

        // 3. Loading model
        onProgress?.invoke(ForecastProgress.LoadingModel)
        yield()
        val transformer = KronosTransformer(modelId)

        // 4. Running inference (supports multi-sample ensemble if sampleCount > 1)
        onProgress?.invoke(ForecastProgress.RunningInference)
        yield()

        val samplePredictions = ArrayList<Array<DoubleArray>>()
        val clampedSampleCount = sampleCount.coerceIn(1, 5)

        for (s in 0 until clampedSampleCount) {
            yield()
            val futureTokens = transformer.generate(
                contextTokens = combinedTokens,
                horizon = horizon,
                temperature = temperature,
                topP = topP
            )

            // Decode this sample path
            val sampleCoarse = IntArray(horizon)
            val sampleFine = IntArray(horizon)
            for (h in 0 until horizon) {
                val (c, f) = tokenizer.fromCombinedToken(futureTokens[h])
                sampleCoarse[h] = c
                sampleFine[h] = f
            }
            val decodedNorm = tokenizer.decode(sampleCoarse, sampleFine)
            samplePredictions.add(decodedNorm)
        }

        // 5. Decoding forecast & inverse normalization
        onProgress?.invoke(ForecastProgress.DecodingForecast)
        yield()

        val lastActualCandle = contextSlice.last()
        var currentRefClose = lastActualCandle.close
        var currentRefTime = lastActualCandle.timestamp

        val forecastCandles = ArrayList<Candle>()

        for (h in 0 until horizon) {
            // Aggregate samples (median for central forecast, min/max for spread)
            val openVals = samplePredictions.map { it[h][0] }.sorted()
            val highVals = samplePredictions.map { it[h][1] }.sorted()
            val lowVals = samplePredictions.map { it[h][2] }.sorted()
            val closeVals = samplePredictions.map { it[h][3] }.sorted()
            val volVals = samplePredictions.map { it[h][4] }.sorted()

            val medianIdx = openVals.size / 2
            val normO = openVals[medianIdx]
            val normH = highVals[medianIdx]
            val normL = lowVals[medianIdx]
            val normC = closeVals[medianIdx]
            val normV = volVals[medianIdx]

            // Inverse normalization
            var predO = normO * stdO + meanO
            var predH = normH * stdH + meanH
            var predL = normL * stdL + meanL
            var predC = normC * stdC + meanC
            var predV = max(0.0, normV * stdV + meanV)

            // Continuity anchoring: first forecast candle starts close to previous close
            if (h == 0) {
                val gap = predO - currentRefClose
                predO = currentRefClose
                predC -= gap * 0.5
                predH -= gap * 0.5
                predL -= gap * 0.5
            }

            // Enforce candlestick physical geometric validity
            val realHigh = max(max(predO, predC), predH)
            val realLow = min(min(predO, predC), max(0.01, predL))

            // Calculate model sample spread if multiple samples were generated
            val spreadLower = if (clampedSampleCount > 1) {
                min(predL, lowVals.first() * stdL + meanL)
            } else null
            val spreadUpper = if (clampedSampleCount > 1) {
                max(realHigh, highVals.last() * stdH + meanH)
            } else null

            currentRefTime += timeframe.intervalMillis

            val candle = Candle(
                timestamp = currentRefTime,
                open = predO,
                high = realHigh,
                low = realLow,
                close = predC,
                volume = predV,
                isForecast = true,
                spreadLower = spreadLower,
                spreadUpper = spreadUpper
            )
            forecastCandles.add(candle)
            currentRefClose = predC
        }

        // 6. Rendering chart notification
        onProgress?.invoke(ForecastProgress.RenderingChart)
        yield()

        val totalTime = System.currentTimeMillis() - startTime

        ForecastResult(
            historicalCandles = contextSlice,
            forecastCandles = forecastCandles,
            modelId = modelId,
            timeframe = timeframe,
            lookbackUsed = effectiveLookback,
            horizon = horizon,
            temperature = temperature,
            topP = topP,
            sampleCount = clampedSampleCount,
            inferenceTimeMs = totalTime
        )
    }
}
