package com.example.core.data

import com.example.core.model.Candle
import com.example.core.model.Timeframe

data class Instrument(
    val symbol: String,
    val name: String,
    val exchange: String,
    val category: MarketCategory,
    val currency: String,
    val timezone: String, // e.g. "Asia/Kolkata", "America/New_York", "UTC"
    val isDemo: Boolean = true,
    val providerId: String = "auto"
)

enum class MarketCategory(val displayName: String) {
    INDIAN_INDICES("Indian Indices"),
    INDIAN_EQUITIES("Indian Equities"),
    US_EQUITIES("US Equities"),
    GLOBAL_EQUITIES("Global Equities"),
    CRYPTO("Crypto"),
    FOREX("Forex"),
    COMMODITIES("Commodities"),
    CUSTOM("Custom / Imported")
}

enum class DataInputMode(val displayName: String, val shortDesc: String) {
    AUTO_MARKET("Auto Market Data", "Zero-cost real-time & historical rates for Global, Indian, Crypto, & FX"),
    CSV_UPLOAD("CSV Upload", "Full dataset parsing, validation, preview, & resampling"),
    SCREENSHOT_IMPORT("Screenshot Import", "On-device OCR extraction from trading charts & terminals")
}

/**
 * Modular data provider interface enabling zero-cost providers to be swapped seamlessly.
 */
interface MarketDataProvider {
    val id: String
    val displayName: String
    val isFree: Boolean get() = true

    suspend fun getHistoricalData(instrument: Instrument, timeframe: Timeframe): List<Candle>
    suspend fun searchInstruments(query: String): List<Instrument>
}
