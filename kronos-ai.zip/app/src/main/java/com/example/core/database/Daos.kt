package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ForecastDao {
    @Query("SELECT * FROM forecasts ORDER BY forecastDate DESC")
    fun getAllForecasts(): Flow<List<ForecastEntity>>

    @Query("SELECT * FROM forecasts ORDER BY forecastDate DESC LIMIT :limit")
    fun getRecentForecasts(limit: Int): Flow<List<ForecastEntity>>

    @Query("SELECT * FROM forecasts WHERE id = :id")
    suspend fun getForecastById(id: Long): ForecastEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertForecast(forecast: ForecastEntity): Long

    @Query("DELETE FROM forecasts WHERE id = :id")
    suspend fun deleteForecastById(id: Long)

    @Query("DELETE FROM forecasts")
    suspend fun clearAll()
}

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM watchlist ORDER BY symbol ASC")
    fun getAllWatchlist(): Flow<List<WatchlistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(item: WatchlistEntity)

    @Query("DELETE FROM watchlist WHERE symbol = :symbol")
    suspend fun removeBySymbol(symbol: String)
}

@Dao
interface DatasetDao {
    @Query("SELECT * FROM datasets ORDER BY importedAt DESC")
    fun getAllDatasets(): Flow<List<DatasetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDataset(dataset: DatasetEntity): Long

    @Query("DELETE FROM datasets WHERE id = :id")
    suspend fun deleteDatasetById(id: Long)

    @Query("DELETE FROM datasets")
    suspend fun clearAll()
}

@Dao
interface BacktestDao {
    @Query("SELECT * FROM backtests ORDER BY timestamp DESC")
    fun getAllBacktests(): Flow<List<BacktestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBacktest(backtest: BacktestEntity): Long

    @Query("DELETE FROM backtests WHERE id = :id")
    suspend fun deleteBacktestById(id: Long)

    @Query("DELETE FROM backtests")
    suspend fun clearAll()
}
