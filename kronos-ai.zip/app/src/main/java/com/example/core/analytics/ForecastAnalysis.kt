package com.example.core.analytics

import com.example.core.model.Candle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class ForecastDirection(val label: String) {
    UP("UP"),
    DOWN("DOWN"),
    MIXED("MIXED / FLAT")
}

data class ForecastAnalysisData(
    val lastActualClose: Double,
    val forecastFinalClose: Double,
    val forecastChangePercent: Double,
    val direction: ForecastDirection,
    val directionBasis: String,
    val firstForecastClose: Double,
    val midForecastClose: Double,
    val maxForecastHigh: Double,
    val minForecastLow: Double,
    val forecastRange: Double,
    val averagePredictedRange: Double,
    val volatilityProxyPercent: Double,
    val maxUpsidePercent: Double,
    val maxDownsidePercent: Double
)

object ForecastAnalysis {

    /**
     * Calculates comprehensive quantitative forecast analysis per Sections 27-31.
     */
    fun analyze(
        historicalCandles: List<Candle>,
        forecastCandles: List<Candle>,
        thresholdPercent: Double = 0.15
    ): ForecastAnalysisData {
        val lastActual = historicalCandles.lastOrNull()?.close ?: 0.0
        val finalForecast = forecastCandles.lastOrNull()?.close ?: lastActual

        val changePct = if (lastActual != 0.0) ((finalForecast - lastActual) / lastActual) * 100.0 else 0.0

        val direction = when {
            changePct > thresholdPercent -> ForecastDirection.UP
            changePct < -thresholdPercent -> ForecastDirection.DOWN
            else -> ForecastDirection.MIXED
        }

        val firstClose = forecastCandles.firstOrNull()?.close ?: lastActual
        val midClose = forecastCandles.getOrNull(forecastCandles.size / 2)?.close ?: lastActual

        var maxHigh = forecastCandles.firstOrNull()?.high ?: lastActual
        var minLow = forecastCandles.firstOrNull()?.low ?: lastActual
        var totalBarRange = 0.0

        for (c in forecastCandles) {
            if (c.high > maxHigh) maxHigh = c.high
            if (c.low < minLow) minLow = c.low
            totalBarRange += (c.high - c.low)
        }

        val forecastRange = maxHigh - minLow
        val avgBarRange = if (forecastCandles.isNotEmpty()) totalBarRange / forecastCandles.size else 0.0

        val maxUpsidePct = if (lastActual != 0.0) ((maxHigh - lastActual) / lastActual) * 100.0 else 0.0
        val maxDownsidePct = if (lastActual != 0.0) ((minLow - lastActual) / lastActual) * 100.0 else 0.0
        val volProxy = if (lastActual != 0.0) (forecastRange / lastActual) * 100.0 else 0.0

        val basis = "Calculated from last actual close (${String.format("%.2f", lastActual)}) " +
                "to final predicted close (${String.format("%.2f", finalForecast)}) " +
                "over ${forecastCandles.size} forecast candles."

        return ForecastAnalysisData(
            lastActualClose = lastActual,
            forecastFinalClose = finalForecast,
            forecastChangePercent = changePct,
            direction = direction,
            directionBasis = basis,
            firstForecastClose = firstClose,
            midForecastClose = midClose,
            maxForecastHigh = maxHigh,
            minForecastLow = minLow,
            forecastRange = forecastRange,
            averagePredictedRange = avgBarRange,
            volatilityProxyPercent = volProxy,
            maxUpsidePercent = maxUpsidePct,
            maxDownsidePercent = maxDownsidePct
        )
    }
}
