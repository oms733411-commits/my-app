package com.example.core.model

/**
 * Represents a single financial candlestick (K-line) in Kronos AI.
 * Follows the standard financial OHLCV format.
 */
data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val isForecast: Boolean = false,
    val spreadLower: Double? = null,
    val spreadUpper: Double? = null
) {
    val change: Double get() = close - open
    val changePercent: Double get() = if (open != 0.0) ((close - open) / open) * 100.0 else 0.0
    val isBullish: Boolean get() = close >= open
    val range: Double get() = high - low
}

enum class Timeframe(val label: String, val intervalMillis: Long, val isIntraday: Boolean) {
    M1("1m", 60_000L, true),
    M5("5m", 300_000L, true),
    M15("15m", 900_000L, true),
    M30("30m", 1_800_000L, true),
    H1("1h", 3_600_000L, true),
    H2("2h", 7_200_000L, true),
    H4("4h", 14_400_000L, true),
    D1("1D", 86_400_000L, false),
    W1("1W", 604_800_000L, false);

    companion object {
        fun fromLabel(label: String): Timeframe =
            entries.firstOrNull { it.label.equals(label, ignoreCase = true) } ?: D1
    }
}
