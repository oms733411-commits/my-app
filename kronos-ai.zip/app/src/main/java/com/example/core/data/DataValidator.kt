package com.example.core.data

import com.example.core.model.Candle

data class ValidationResult(
    val isValid: Boolean,
    val errors: List<String>,
    val warnings: List<String>,
    val rowCount: Int,
    val startDateFormatted: String,
    val endDateFormatted: String,
    val hasVolume: Boolean
)

object DataValidator {

    /**
     * Validates an imported dataset per Section 17 requirements.
     */
    fun validate(candles: List<Candle>): ValidationResult {
        val errors = ArrayList<String>()
        val warnings = ArrayList<String>()

        if (candles.isEmpty()) {
            errors.add("Dataset contains zero valid rows.")
            return ValidationResult(false, errors, warnings, 0, "N/A", "N/A", false)
        }

        if (candles.size < 10) {
            warnings.add("Dataset contains only ${candles.size} rows. At least 30 rows recommended for optimal model context.")
        }

        var missingOhlcCount = 0
        var highLessThanLowCount = 0
        var closeOutsideRangeCount = 0
        var invalidVolumeCount = 0
        var zeroVolumeCount = 0
        var duplicateTimestamps = 0
        var unsortedTimestamps = 0

        val seenTimestamps = HashSet<Long>()
        var prevTime = -1L

        for (i in candles.indices) {
            val c = candles[i]

            // Timestamps
            if (!seenTimestamps.add(c.timestamp)) {
                duplicateTimestamps++
            }
            if (prevTime > 0 && c.timestamp <= prevTime) {
                unsortedTimestamps++
            }
            prevTime = c.timestamp

            // Missing / NaN / Infinity check
            if (c.open.isNaN() || c.open.isInfinite() ||
                c.high.isNaN() || c.high.isInfinite() ||
                c.low.isNaN() || c.low.isInfinite() ||
                c.close.isNaN() || c.close.isInfinite()
            ) {
                missingOhlcCount++
            }

            // High < Low
            if (c.high < c.low) {
                highLessThanLowCount++
            }

            // Close outside High/Low
            if (c.close > c.high + 1e-4 || c.close < c.low - 1e-4) {
                closeOutsideRangeCount++
            }

            // Volume
            if (c.volume.isNaN() || c.volume < 0.0) {
                invalidVolumeCount++
            } else if (c.volume == 0.0) {
                zeroVolumeCount++
            }
        }

        if (missingOhlcCount > 0) errors.add("Found $missingOhlcCount rows with NaN or Infinite OHLC values.")
        if (highLessThanLowCount > 0) errors.add("Found $highLessThanLowCount rows where High is strictly less than Low.")
        if (unsortedTimestamps > 0) warnings.add("Found $unsortedTimestamps unsorted timestamp entries (will be sorted automatically).")
        if (duplicateTimestamps > 0) warnings.add("Found $duplicateTimestamps duplicate timestamp entries.")
        if (closeOutsideRangeCount > 0) warnings.add("Found $closeOutsideRangeCount rows where Close lies slightly outside High/Low bounds.")
        if (invalidVolumeCount > 0) warnings.add("Found $invalidVolumeCount rows with invalid negative volume.")
        if (zeroVolumeCount == candles.size) warnings.add("Volume is unavailable or zero across all rows. Model will run price-only inference.")

        val hasVolume = zeroVolumeCount < candles.size

        val sorted = candles.sortedBy { it.timestamp }
        val startDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(sorted.first().timestamp))
        val endDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(sorted.last().timestamp))

        return ValidationResult(
            isValid = errors.isEmpty(),
            errors = errors,
            warnings = warnings,
            rowCount = candles.size,
            startDateFormatted = startDate,
            endDateFormatted = endDate,
            hasVolume = hasVolume
        )
    }
}
