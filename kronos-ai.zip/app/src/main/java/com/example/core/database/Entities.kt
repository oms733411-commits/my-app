package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "forecasts")
data class ForecastEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val market: String,
    val timeframe: String,
    val modelName: String,
    val forecastDate: Long,
    val horizon: Int,
    val lookback: Int,
    val lastActualClose: Double,
    val finalForecastClose: Double,
    val forecastChangePercent: Double,
    val direction: String,
    val temperature: Float,
    val topP: Float,
    val sampleCount: Int,
    val forecastJson: String,
    val actualOutcomeClose: Double? = null
)

@Entity(tableName = "watchlist")
data class WatchlistEntity(
    @PrimaryKey val symbol: String,
    val name: String,
    val exchange: String,
    val category: String,
    val lastPrice: Double,
    val lastDirection: String,
    val lastChangePercent: Double,
    val lastForecastDate: Long
)

@Entity(tableName = "datasets")
data class DatasetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val symbol: String,
    val rowCount: Int,
    val startDate: String,
    val endDate: String,
    val hasVolume: Boolean,
    val rawCsvContent: String,
    val importedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "backtests")
data class BacktestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val timeframe: String,
    val modelName: String,
    val lookback: Int,
    val horizon: Int,
    val numWindows: Int,
    val kronosMae: Double,
    val kronosRmse: Double,
    val kronosMape: Double,
    val kronosDirAcc: Double,
    val naiveMae: Double,
    val naiveRmse: Double,
    val naiveDirAcc: Double,
    val timestamp: Long = System.currentTimeMillis()
)
