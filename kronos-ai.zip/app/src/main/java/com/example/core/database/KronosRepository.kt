package com.example.core.database

import com.example.core.model.Candle
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class KronosRepository(private val database: KronosDatabase) {

    val allForecasts: Flow<List<ForecastEntity>> = database.forecastDao().getAllForecasts()
    val recentForecasts: Flow<List<ForecastEntity>> = database.forecastDao().getRecentForecasts(5)
    val allWatchlist: Flow<List<WatchlistEntity>> = database.watchlistDao().getAllWatchlist()
    val allDatasets: Flow<List<DatasetEntity>> = database.datasetDao().getAllDatasets()
    val allBacktests: Flow<List<BacktestEntity>> = database.backtestDao().getAllBacktests()

    suspend fun saveForecast(
        symbol: String,
        market: String,
        timeframe: String,
        modelName: String,
        horizon: Int,
        lookback: Int,
        lastActualClose: Double,
        finalForecastClose: Double,
        forecastChangePercent: Double,
        direction: String,
        temperature: Float,
        topP: Float,
        sampleCount: Int,
        forecastCandles: List<Candle>
    ): Long {
        val jsonArray = JSONArray()
        for (c in forecastCandles) {
            val obj = JSONObject()
            obj.put("timestamp", c.timestamp)
            obj.put("open", c.open)
            obj.put("high", c.high)
            obj.put("low", c.low)
            obj.put("close", c.close)
            obj.put("volume", c.volume)
            c.spreadLower?.let { obj.put("spreadLower", it) }
            c.spreadUpper?.let { obj.put("spreadUpper", it) }
            jsonArray.put(obj)
        }

        val entity = ForecastEntity(
            symbol = symbol,
            market = market,
            timeframe = timeframe,
            modelName = modelName,
            forecastDate = System.currentTimeMillis(),
            horizon = horizon,
            lookback = lookback,
            lastActualClose = lastActualClose,
            finalForecastClose = finalForecastClose,
            forecastChangePercent = forecastChangePercent,
            direction = direction,
            temperature = temperature,
            topP = topP,
            sampleCount = sampleCount,
            forecastJson = jsonArray.toString()
        )
        return database.forecastDao().insertForecast(entity)
    }

    fun parseForecastCandles(json: String): List<Candle> {
        val list = ArrayList<Candle>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    Candle(
                        timestamp = obj.getLong("timestamp"),
                        open = obj.getDouble("open"),
                        high = obj.getDouble("high"),
                        low = obj.getDouble("low"),
                        close = obj.getDouble("close"),
                        volume = obj.getDouble("volume"),
                        isForecast = true,
                        spreadLower = if (obj.has("spreadLower")) obj.getDouble("spreadLower") else null,
                        spreadUpper = if (obj.has("spreadUpper")) obj.getDouble("spreadUpper") else null
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    suspend fun deleteForecast(id: Long) = database.forecastDao().deleteForecastById(id)

    suspend fun addToWatchlist(item: WatchlistEntity) = database.watchlistDao().insertOrUpdate(item)

    suspend fun removeFromWatchlist(symbol: String) = database.watchlistDao().removeBySymbol(symbol)

    suspend fun saveDataset(dataset: DatasetEntity) = database.datasetDao().insertDataset(dataset)

    suspend fun deleteDataset(id: Long) = database.datasetDao().deleteDatasetById(id)

    suspend fun saveBacktest(backtest: BacktestEntity) = database.backtestDao().insertBacktest(backtest)

    suspend fun deleteBacktest(id: Long) = database.backtestDao().deleteBacktestById(id)

    suspend fun clearHistory() = database.forecastDao().clearAll()

    suspend fun clearAllData() {
        database.forecastDao().clearAll()
        database.datasetDao().clearAll()
        database.backtestDao().clearAll()
    }
}
