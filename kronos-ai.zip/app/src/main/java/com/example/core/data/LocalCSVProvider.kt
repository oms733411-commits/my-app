package com.example.core.data

import com.example.core.model.Candle
import java.io.BufferedReader
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

object LocalCSVProvider {

    private val dateFormats = listOf(
        "yyyy-MM-dd'T'HH:mm:ss'Z'",
        "yyyy-MM-dd'T'HH:mm:ss",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd HH:mm",
        "yyyy-MM-dd",
        "dd/MM/yyyy HH:mm:ss",
        "dd/MM/yyyy",
        "MM/dd/yyyy"
    )

    data class ParsedCSV(
        val candles: List<Candle>,
        val headerMap: Map<String, Int>,
        val previewRows: List<Map<String, String>>,
        val validationResult: ValidationResult
    )

    /**
     * Parses raw CSV content into candles and validates the data.
     */
    fun parse(csvContent: String): ParsedCSV {
        val reader = BufferedReader(StringReader(csvContent))
        val lines = reader.readLines().filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            throw IllegalArgumentException("CSV file is empty.")
        }

        val headerTokens = lines[0].split(",").map { it.trim().replace("\"", "") }
        val headerMap = HashMap<String, Int>()
        for (i in headerTokens.indices) {
            headerMap[headerTokens[i].lowercase(Locale.ROOT)] = i
        }

        val timeIdx = headerMap["timestamp"] ?: headerMap["datetime"] ?: headerMap["date"] ?: headerMap["time"]
        val openIdx = headerMap["open"]
        val highIdx = headerMap["high"]
        val lowIdx = headerMap["low"]
        val closeIdx = headerMap["close"]
        val volIdx = headerMap["volume"] ?: headerMap["vol"] ?: headerMap["amount"]

        if (openIdx == null || highIdx == null || lowIdx == null || closeIdx == null) {
            throw IllegalArgumentException("Missing required OHLC columns. Found columns: ${headerTokens.joinToString(", ")}")
        }

        val candles = ArrayList<Candle>()
        val previewRows = ArrayList<Map<String, String>>()

        for (rowIdx in 1 until lines.size) {
            val line = lines[rowIdx]
            val cols = line.split(",").map { it.trim().replace("\"", "") }
            if (cols.size < 4) continue

            // Preview rows
            if (previewRows.size < 20) {
                val map = HashMap<String, String>()
                for (h in headerTokens.indices) {
                    if (h < cols.size) map[headerTokens[h]] = cols[h]
                }
                previewRows.add(map)
            }

            val timestamp = if (timeIdx != null && timeIdx < cols.size) {
                parseTimestamp(cols[timeIdx], rowIdx)
            } else {
                1704067200000L + (rowIdx * 86400000L)
            }

            val open = cols.getOrNull(openIdx)?.toDoubleOrNull() ?: 0.0
            val high = cols.getOrNull(highIdx)?.toDoubleOrNull() ?: 0.0
            val low = cols.getOrNull(lowIdx)?.toDoubleOrNull() ?: 0.0
            val close = cols.getOrNull(closeIdx)?.toDoubleOrNull() ?: 0.0
            val volume = if (volIdx != null && volIdx < cols.size) cols[volIdx].toDoubleOrNull() ?: 0.0 else 0.0

            candles.add(
                Candle(
                    timestamp = timestamp,
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = volume
                )
            )
        }

        val sortedCandles = candles.sortedBy { it.timestamp }
        val validation = DataValidator.validate(sortedCandles)

        return ParsedCSV(
            candles = sortedCandles,
            headerMap = headerMap,
            previewRows = previewRows,
            validationResult = validation
        )
    }

    private fun parseTimestamp(raw: String, rowIdx: Int): Long {
        // Try direct number (epoch millis or epoch seconds)
        raw.toLongOrNull()?.let { num ->
            return if (num < 10000000000L) num * 1000L else num
        }

        for (pattern in dateFormats) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.US)
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                val d = sdf.parse(raw)
                if (d != null) return d.time
            } catch (_: Exception) {}
        }

        return 1704067200000L + (rowIdx * 86400000L)
    }
}
