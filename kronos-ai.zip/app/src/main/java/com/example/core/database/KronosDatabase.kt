package com.example.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ForecastEntity::class,
        WatchlistEntity::class,
        DatasetEntity::class,
        BacktestEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class KronosDatabase : RoomDatabase() {
    abstract fun forecastDao(): ForecastDao
    abstract fun watchlistDao(): WatchlistDao
    abstract fun datasetDao(): DatasetDao
    abstract fun backtestDao(): BacktestDao

    companion object {
        @Volatile
        private var INSTANCE: KronosDatabase? = null

        fun getInstance(context: Context): KronosDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KronosDatabase::class.java,
                    "kronos_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
