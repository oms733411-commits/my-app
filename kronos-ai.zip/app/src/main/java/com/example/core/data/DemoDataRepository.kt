package com.example.core.data

import com.example.core.model.Candle
import com.example.core.model.Timeframe
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object DemoDataRepository : MarketDataProvider {

    override val id: String = "local_quant_engine"
    override val displayName: String = "Local Quantitative Engine (Offline)"
    override val isFree: Boolean = true

    override suspend fun getHistoricalData(instrument: Instrument, timeframe: Timeframe): List<Candle> {
        val baseCandles = generateDeterministicDataset(instrument)
        return if (timeframe == Timeframe.D1) {
            baseCandles
        } else {
            TimeframeResampler.resample(baseCandles, timeframe)
        }
    }

    override suspend fun searchInstruments(query: String): List<Instrument> {
        return MarketRegistry.search(query)
    }

    /**
     * Generates a deterministic realistic financial dataset tailored to the asset's scale and volatility.
     */
    private fun generateDeterministicDataset(instrument: Instrument): List<Candle> {
        val (basePrice, volatility, baseVolume) = when (instrument.symbol) {
            "NIFTY 50" -> Triple(22500.0, 140.0, 180000000.0)
            "BANK NIFTY" -> Triple(48200.0, 320.0, 120000000.0)
            "SENSEX" -> Triple(74000.0, 450.0, 95000000.0)
            "RELIANCE" -> Triple(2920.0, 24.0, 4500000.0)
            "TCS" -> Triple(3880.0, 32.0, 2100000.0)
            "INFY" -> Triple(1520.0, 16.0, 6800000.0)
            "HDFCBANK" -> Triple(1680.0, 18.0, 8500000.0)
            "ICICIBANK" -> Triple(1150.0, 14.0, 7200000.0)
            "AAPL" -> Triple(185.0, 2.2, 45000000.0)
            "MSFT" -> Triple(420.0, 4.5, 22000000.0)
            "NVDA" -> Triple(125.0, 3.8, 65000000.0)
            "TSLA" -> Triple(215.0, 5.2, 58000000.0)
            "GOOGL" -> Triple(175.0, 2.8, 28000000.0)
            "BTC/USDT" -> Triple(64000.0, 1200.0, 28000.0)
            "ETH/USDT" -> Triple(3450.0, 85.0, 145000.0)
            "SOL/USDT" -> Triple(145.0, 6.5, 340000.0)
            "EUR/USD" -> Triple(1.0850, 0.0035, 120000.0)
            "GBP/USD" -> Triple(1.2720, 0.0042, 95000.0)
            "USD/INR" -> Triple(83.50, 0.12, 420000.0)
            "GOLD" -> Triple(2380.0, 18.0, 85000.0)
            "CRUDE" -> Triple(82.50, 1.4, 110000.0)
            else -> Triple(100.0, 1.5, 100000.0)
        }

        val count = 180
        val candles = ArrayList<Candle>(count)
        val endEpoch = System.currentTimeMillis() - (86400000L * 2) // Up to yesterday
        val startEpoch = endEpoch - (count * 86400000L)

        var currentPrice = basePrice

        for (i in 0 until count) {
            val t = startEpoch + (i * 86400000L)

            // Deterministic cyclical + trend wave
            val wave1 = sin(i * 0.08) * volatility * 1.8
            val wave2 = cos(i * 0.22) * volatility * 0.9
            val trend = (i - (count / 2)) * (volatility * 0.04)
            val noise = (sin(i * 1.414) + cos(i * 2.718)) * (volatility * 0.5)

            val open = currentPrice
            val close = (basePrice + wave1 + wave2 + trend + noise).coerceAtLeast(0.01)

            val barRange = abs(close - open) + (abs(sin(i * 0.9)) * volatility * 0.6)
            val high = max(open, close) + (abs(cos(i * 0.5)) * barRange * 0.6)
            val low = min(open, close) - (abs(sin(i * 0.7)) * barRange * 0.6).coerceAtLeast(0.01)

            val volOscillator = 1.0 + 0.4 * sin(i * 0.3) + 0.2 * cos(i * 0.8)
            val volume = max(100.0, baseVolume * volOscillator)

            candles.add(
                Candle(
                    timestamp = t,
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = volume,
                    isForecast = false
                )
            )

            currentPrice = close
        }

        return candles
    }
}
