package com.example

import com.example.core.analytics.ForecastAnalysis
import com.example.core.analytics.ForecastDirection
import com.example.core.data.DataValidator
import com.example.core.data.DemoDataRepository
import com.example.core.data.FreePublicMarketDataProvider
import com.example.core.data.LocalCSVProvider
import com.example.core.data.MarketRegistry
import com.example.core.model.Candle
import com.example.core.model.KronosTokenizer
import com.example.core.model.Timeframe
import com.example.core.ocr.FinancialChartOcrExtractor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testKronosTokenizer_encodeDecode() {
        val tokenizer = KronosTokenizer()
        val testVectors = Array(10) { i ->
            doubleArrayOf(0.1 * i, 0.15 * i, -0.05 * i, 0.12 * i, 1.0)
        }

        val (coarse, fine) = tokenizer.encode(testVectors)
        assertEquals(10, coarse.size)
        assertEquals(10, fine.size)

        for (i in 0 until 10) {
            assertTrue("Coarse token within range", coarse[i] in 0 until 32)
            assertTrue("Fine token within range", fine[i] in 0 until 64)

            val combined = tokenizer.toCombinedToken(coarse[i], fine[i])
            val (cRecovered, fRecovered) = tokenizer.fromCombinedToken(combined)
            assertEquals(coarse[i], cRecovered)
            assertEquals(fine[i], fRecovered)
        }

        val decoded = tokenizer.decode(coarse, fine)
        assertEquals(10, decoded.size)
        assertEquals(5, decoded[0].size)
    }

    @Test
    fun testDataValidator_validData() {
        val candles = listOf(
            Candle(1000L, 100.0, 105.0, 99.0, 103.0, 5000.0),
            Candle(2000L, 103.0, 107.0, 102.0, 106.0, 6000.0),
            Candle(3000L, 106.0, 110.0, 105.0, 108.0, 5500.0)
        )
        val result = DataValidator.validate(candles)
        assertTrue(result.isValid)
        assertEquals(0, result.errors.size)
        assertEquals(3, result.rowCount)
    }

    @Test
    fun testDataValidator_detectsInvalidHighLow() {
        val invalidCandles = listOf(
            Candle(1000L, 100.0, 95.0, 105.0, 100.0, 5000.0) // High < Low!
        )
        val result = DataValidator.validate(invalidCandles)
        assertFalse(result.isValid)
        assertTrue(result.errors.any { it.contains("High is strictly less than Low") })
    }

    @Test
    fun testForecastAnalysis_upDirection() {
        val historical = listOf(Candle(1000L, 100.0, 102.0, 99.0, 100.0, 1000.0))
        val forecast = listOf(
            Candle(2000L, 100.0, 105.0, 99.0, 103.0, 1000.0, isForecast = true),
            Candle(3000L, 103.0, 108.0, 102.0, 106.0, 1000.0, isForecast = true)
        )
        val analysis = ForecastAnalysis.analyze(historical, forecast)
        assertEquals(ForecastDirection.UP, analysis.direction)
        assertEquals(100.0, analysis.lastActualClose, 0.001)
        assertEquals(106.0, analysis.forecastFinalClose, 0.001)
        assertEquals(6.0, analysis.forecastChangePercent, 0.01)
    }

    @Test
    fun testLocalCSVProvider_parsing() {
        val csv = """
            date,open,high,low,close,volume
            2024-01-01,150.0,155.0,148.0,152.0,100000
            2024-01-02,152.0,158.0,151.0,156.0,120000
        """.trimIndent()

        val parsed = LocalCSVProvider.parse(csv)
        assertEquals(2, parsed.candles.size)
        assertEquals(150.0, parsed.candles[0].open, 0.001)
        assertEquals(156.0, parsed.candles[1].close, 0.001)
        assertTrue(parsed.validationResult.isValid)
    }

    @Test
    fun testFinancialChartOcrExtractor_headerExtraction() {
        val headerText = "NIFTY 50 • 1D • NSE\nO: 22450.00 H: 22530.00 L: 22410.00 C: 22510.50 Vol: 180M"
        val result = FinancialChartOcrExtractor.extractFromText(headerText)

        assertTrue("OCR extraction should succeed", result.success)
        assertEquals("NIFTY", result.detectedSymbol?.substringBefore(" "))
        assertNotNull(result.detectedOhlc)
        assertEquals(22450.00, result.detectedOhlc!!.open!!, 0.01)
        assertEquals(22530.00, result.detectedOhlc!!.high!!, 0.01)
        assertEquals(22410.00, result.detectedOhlc!!.low!!, 0.01)
        assertEquals(22510.50, result.detectedOhlc!!.close!!, 0.01)
        assertTrue("Extracted candles context should not be empty", result.extractedCandles.isNotEmpty())
        assertEquals(60, result.extractedCandles.size)
    }

    @Test
    fun testFinancialChartOcrExtractor_tabularRows() {
        val tableText = """
            1704067200000 2450.0 2480.0 2440.0 2470.0 10000
            1704153600000 2470.0 2490.0 2465.0 2485.0 12000
            1704240000000 2485.0 2510.0 2480.0 2505.0 15000
            1704326400000 2505.0 2520.0 2495.0 2515.0 11000
            1704412800000 2515.0 2530.0 2500.0 2525.0 14000
        """.trimIndent()

        val result = FinancialChartOcrExtractor.extractFromText(tableText)
        assertTrue(result.success)
        assertEquals(5, result.extractedCandles.size)
        assertEquals(2450.0, result.extractedCandles[0].open, 0.01)
        assertEquals(2525.0, result.extractedCandles.last().close, 0.01)
    }

    @Test
    fun testMarketDataProvider_offlineFallback() = runBlocking {
        val instrument = MarketRegistry.findBySymbol("NIFTY 50")!!
        val candles = FreePublicMarketDataProvider.getHistoricalData(instrument, Timeframe.D1)
        assertNotNull(candles)
        assertTrue(candles.size >= 60)
        assertTrue(candles.all { it.high >= it.low })
    }
}
